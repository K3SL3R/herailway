---
name: windows-tooling
description: >
  Windows-specific tooling patterns for Hermes on Windows via git-bash/MSYS.
  Covers the PowerShell escaping problem, WMIC workarounds, disk management,
  cleanup workflows, and running admin-requiring operations.
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [windows, powershell, bash, msvs, tooling, escaping, disk-cleanup]
    related_skills: []
---

# Windows Tooling (git-bash/MSYS)

Hermes on Windows runs inside **git-bash (MSYS)**, NOT PowerShell or cmd.exe.
This creates specific escaping issues when running PowerShell commands from the `terminal` tool.

---

## Core Problem: PowerShell `$_` escaping in bash

The biggest pitfall: **bash expands `$_` before PowerShell ever sees it**.

```bash
# ❌ WRONG — bash expands $_ to something else
$ powershell -Command "Get-ChildItem C:\Users\Shayan | ForEach-Object { Write-Host $_.Name }"
# → bash sees $_.Name → evaluates $_ (last arg of prev command) → breaks
```

Also: `$()`, `$var`, and backtick characters get consumed by bash.

### Three Reliable Workarounds

#### Workaround 1: Write .ps1 script files (RECOMMENDED for complex commands)

```python
# First, write the script:
write_file(path="C:\\path\\to\\script.ps1", content="""\
$folders = @("Windows", "Users", "Program Files")
foreach ($f in $folders) {
    if (Test-Path "C:\\$f") {
        Write-Host "$f exists"
        # Use $f in PowerShell expressions freely — no escaping needed
    }
}
""")

# Then execute it:
terminal("powershell -NoProfile -ExecutionPolicy Bypass -File 'C:\\path\\to\\script.ps1'", timeout=60)
```

**When to use:**
- Commands with `$_`, `$variable`, `$()` constructs
- Multi-line or complex PowerShell logic
- Any time the one-liner looks fragile

#### Workaround 2: Use `execute_code` + `terminal()` from Python

```python
from hermes_tools import terminal

r = terminal('powershell -NoProfile -Command "Get-PSDrive C | Format-List"', timeout=15)
print(r["output"])
```

**When to use:**
- Short single-line commands
- When you need to process output in Python anyway
- The escaping is simpler since you're in a Python string

#### Workaround 3: WMIC for simple queries (NO escaping issues)

```bash
# This works perfectly from bash — no $_ or $ escaping at all
$ wmic logicaldisk where "DeviceID='C:'" get Size,FreeSpace /format:list
```

**When to use:**
- Hardware/drive queries
- Simple system info that WMIC supports
- Avoiding PowerShell entirely for trivial reads

---

## Simple PowerShell Queries That Work (inline)

Some simple forms survive bash escaping:

```bash
# OK — single command, no $_ 
powershell -NoProfile -Command "Get-PSDrive C"

# OK — simple string literal, no special chars
powershell -NoProfile -Command "Write-Host 'hello'"

# Works — IF you use backtick-escaping of $
powershell -NoProfile -Command "Get-ChildItem 'C:\\Users' -Directory | ForEach-Object { Write-Host \`$_.Name }"
```

---

## Drive & Disk Inspection Workflow

A tested sequence for profiling drive C: space usage:

### Quick check (no escaping issues):
```bash
wmic logicaldisk where "DeviceID='C:'" get Size,FreeSpace /format:list
# → FreeSpace=14072348672
# → Size=126279192576
```

### Then convert in Python:
```python
free_gb = round(14072348672 / 1024**3, 2)  # → 13.11 GB
```

### Full scan (write a .ps1):

See `references/disk-scan-template.ps1` for a complete template that
scans top-level folders, Users, Program Files, AppData, and Windows.

---

## Admin vs Non-Admin Context

**IMPORTANT**: The `terminal` tool runs as the logged-in user, NOT as Administrator.
Operations that need elevation:

| Operation | Admin needed? | Notes |
|-----------|:------------:|-------|
| Delete `C:\Windows\Panther\*` | ✅ Yes | System-owned files |
| Delete `C:\ProgramData\Package Cache\*` | ✅ Yes | System-owned |
| Delete NVIDIA DXCache (user's AppData) | ❌ No | User-owned — safe |
| Delete user's Temp | ❌ No | User-owned |
| DISM /StartComponentCleanup | ✅ Yes | System image |
| cleanmgr.exe (system files) | ✅ Yes | For full cleanup |

For admin-required operations, inform the user and provide the exact command
they can paste into an elevated PowerShell window.

---

## Cleanup Reference Values

Common reclaimable items on a typical Windows 11 C: drive:

| Item | Typical size | Admin? | Safe? |
|------|:-----------:|:------:|:-----:|
| NVIDIA DXCache | 1-6 GB | No | ✅ Safe |
| Package Cache | 2-5 GB | Yes | ✅ Safe |
| Windows Panther | 0.5-2 GB | Yes | ✅ After stable update |
| WinSxS (via DISM) | 3-8 GB | Yes | ⚠️ Read section 2.1 |
| Windows Temp | 0-2 GB | Partially | ✅ Safe |
| User Temp | 0-5 GB | No | ✅ Safe |
| Browser Cache | 1-10 GB | No | ⚠️ May lose session data |

---

## Pitfalls

- **NEVER** delete `C:\Windows\Installer\` manually — breaks uninstall/repair.
- **NEVER** tell the user to use CCleaner or registry cleaners.
- **NEVER** delete WinSxS folders manually — use `DISM /Online /Cleanup-Image`.
- **NEVER** run `DISM /ResetBase` within 2 weeks of a Windows update.
- **ALWAYS** verify free space after cleanup with `wmic` (not inline PowerShell).
- **ALWAYS** confirm user consent before deleting anything over 100 MB — mark as completed only after verification.