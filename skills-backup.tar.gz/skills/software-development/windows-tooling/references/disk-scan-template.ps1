<#
.SYNOPSIS
    Full scan of C:\ drive — folder sizes, system files, user profiles.
    Run from: powershell -NoProfile -ExecutionPolicy Bypass -File scan.ps1
.NOTES
    Designed to be called from Hermes terminal tool on Windows.
    Avoids all $_ and $variable escaping issues by being standalone.
#>

Write-Host "=== DRIVE C: SUMMARY ==="
$drive = Get-PSDrive C
$totalGB = [math]::Round(($drive.Used + $drive.Free) / 1GB, 2)
$freeGB  = [math]::Round($drive.Free / 1GB, 2)
$usedGB  = [math]::Round($drive.Used / 1GB, 2)
$pctFree = [math]::Round($drive.Free / ($drive.Used + $drive.Free) * 100, 1)
Write-Host "Total: $totalGB GB | Used: $usedGB GB | Free: $freeGB GB ($pctFree%)"

Write-Host ""
Write-Host "=== TOP-LEVEL FOLDERS (GB) ==="
$topDirs = @("Windows", "Users", "Program Files", "Program Files (x86)",
             "ProgramData", "PerfLogs", "Intel", "MSOCache")
foreach ($d in $topDirs) {
    $p = "C:\$d"
    if (Test-Path $p) {
        try {
            $size = (Get-ChildItem $p -Recurse -File -ErrorAction SilentlyContinue |
                     Measure-Object -Property Length -Sum).Sum
            Write-Host "$d : $([math]::Round($size/1GB,2)) GB"
        } catch { Write-Host "$d : access denied" }
    } else { Write-Host "$d : not found" }
}

Write-Host ""
Write-Host "=== USERS (GB) ==="
Get-ChildItem "C:\Users" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue |
                 Measure-Object -Property Length -Sum).Sum
        Write-Host "$($_.Name) : $([math]::Round($size/1GB,2)) GB"
    } catch { Write-Host "$($_.Name) : access denied" }
}

Write-Host ""
Write-Host "=== LARGE SYSTEM FILES ==="
foreach ($f in @("C:\hiberfil.sys", "C:\pagefile.sys", "C:\swapfile.sys")) {
    if (Test-Path $f) {
        $fi = Get-Item $f -Force
        Write-Host "$f : $([math]::Round($fi.Length/1GB,2)) GB"
    } else { Write-Host "$f : not found" }
}

Write-Host ""
Write-Host "=== TEMP & CACHE FOLDERS (GB) ==="
$cachePaths = @(
    "C:\Windows\Temp",
    "C:\Windows\SoftwareDistribution\Download",
    "C:\Windows\Prefetch",
    "C:\Windows\Installer",
    "C:\$Recycle.Bin",
    "$env:LOCALAPPDATA\Temp",
    "$env:LOCALAPPDATA\NVIDIA\DXCache",
    "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache",
    "$env:LOCALAPPDATA\Microsoft\Windows\INetCache"
)
foreach ($p in $cachePaths) {
    if (Test-Path $p) {
        try {
            $size = (Get-ChildItem $p -Recurse -File -ErrorAction SilentlyContinue |
                     Measure-Object -Property Length -Sum).Sum
            Write-Host "$p : $([math]::Round($size/1GB,2)) GB"
        } catch { Write-Host "$p : access denied" }
    } else { Write-Host "$p : not found" }
}

Write-Host ""
Write-Host "=== DONE ==="