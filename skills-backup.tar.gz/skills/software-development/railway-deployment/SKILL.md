---
name: railway-deployment
description: Deploy Docker and Node.js applications to Railway with persistent storage, environment configuration, and public networking
tags: [railway, deployment, docker, cloud, paas, nodejs]
---

# Railway Deployment

Deploy containerized applications to Railway.app — a modern PaaS with generous free tier, automatic Docker detection, and simple persistent volume support.

## When to Use

- Need free hosting with 500 hours/month + $5 credit (~20 days continuous uptime)
- Docker or Node.js application
- Requires persistent storage (SQLite, file uploads, etc.)
- Need always-on service (unlike Render free tier which sleeps after 15min)
- Want auto-deploy from GitHub
- Need public HTTPS endpoint with custom domain support

**Alternatives:**
- Fly.io: better for edge/multi-region, more complex setup
- Render: easier for simple apps, but free tier sleeps
- Vercel/Netlify: serverless only, no persistent state
- Google Cloud Run: pay-per-use, requires more GCP knowledge

## Prerequisites

1. GitHub account
2. Railway account (signup via GitHub at https://railway.app)
3. Application with Dockerfile OR package.json
4. Understanding of required environment variables

## Deployment Workflow

### 1. Prepare Repository

**Option A: Deploy from GitHub (recommended)**
- Fork or push your code to GitHub
- Ensure Dockerfile exists OR package.json with proper start script

**Option B: Deploy from local**
- Use Railway CLI: `railway login` → `railway init` → `railway up`

### 2. Create Project in Railway

1. Railway Dashboard → **New Project**
2. **Deploy from GitHub repo** → select repository
3. Railway auto-detects:
   - Dockerfile → builds via Docker
   - package.json → uses Node buildpack
   - Other frameworks via Nixpacks detection

### 3. Configure Environment Variables

Navigate to **Variables** tab and add required vars:

**Common patterns:**
```bash
# Security secrets (generate random 32+ char strings)
JWT_SECRET=<random-hex-64-chars>
API_KEY=<random-string>
SESSION_SECRET=<random-string>

# Application config
NODE_ENV=production
PORT=8080              # or app's default port
HOSTNAME=0.0.0.0       # critical for Railway networking

# Database/storage paths (if using volumes)
DATA_DIR=/app/data
DATABASE_URL=/app/data/db.sqlite
```

**Generate secure secrets:**
```bash
# Node.js crypto (32 bytes = 64 hex chars)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# OpenSSL alternative
openssl rand -hex 32

# UUID
uuidgen
```

### 4. Add Persistent Storage (if needed)

For SQLite, file uploads, or any persistent data:

1. **Volumes** tab → **New Volume**
2. **Mount Path:** `/app/data` (or app's data directory)
3. **Size:** 1-10GB depending on needs
4. Ensure environment variable points to mount path:
   ```
   DATA_DIR=/app/data
   DATABASE_URL=/app/data/database.sqlite
   ```

**Critical:** Volume mount path must match the DATA_DIR/database path in your app code.

### 5. Configure Networking

**Public access:**
1. **Settings** → **Networking** → **Public Networking**
2. **Generate Domain** → gets URL like `app-name-production.up.railway.app`
3. Optional: Add custom domain via **Domains** section

**Internal services:**
- Railway provides automatic service discovery via environment variables
- Access other services: `http://<service-name>:PORT`

### 6. Deploy and Monitor

1. Railway auto-builds and deploys on project creation
2. **Deployments** tab → monitor build progress (3-5 minutes typical)
3. **View Logs** → real-time application logs
4. Status indicators:
   - **Building** → compiling/dockerizing
   - **Deploying** → starting container
   - **Active** → running and healthy
   - **Failed** → check logs for errors

### 7. Verification

```bash
# Test public endpoint
curl https://your-app.up.railway.app/health

# Check specific API
curl https://your-app.up.railway.app/api/status
```

Dashboard health checks:
- **Metrics** tab shows CPU, memory, network usage
- **Logs** tab shows application output

## Configuration Files

### railway.toml (optional but recommended)

```toml
[build]
builder = "DOCKERFILE"
dockerfilePath = "Dockerfile"

[deploy]
startCommand = "node server.js"
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 10
```

For Node.js without Docker:
```toml
[build]
builder = "NIXPACKS"

[deploy]
startCommand = "npm start"
```

### Dockerfile Best Practices

```dockerfile
FROM node:20-alpine
WORKDIR /app

# Install dependencies first (cache layer)
COPY package*.json ./
RUN npm ci --production

# Copy application
COPY . .

# Expose port (Railway ignores EXPOSE, reads from PORT env)
EXPOSE 8080

# Create data directory if using volumes
RUN mkdir -p /app/data && chown node:node /app/data

USER node
CMD ["node", "server.js"]
```

**Key points:**
- Use `HOSTNAME=0.0.0.0` to bind to all interfaces
- Railway injects `PORT` env var — read it, don't hardcode
- Create directories for volume mount paths during build
- Run as non-root user for security

## Common Pitfalls

### "Application failed to respond"
**Causes:**
- App not binding to `0.0.0.0` (using `localhost` or `127.0.0.1`)
- Not reading `PORT` env var from Railway
- App crashing on startup (check logs)

**Fix:**
```javascript
// WRONG
app.listen(3000, 'localhost');

// RIGHT
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0');
```

### "Database/file errors"
**Causes:**
- Volume not mounted
- Mount path mismatch between volume config and app code
- Permissions issues (app not writing to mounted path)

**Fix:**
- Verify volume mount path exactly matches DATA_DIR env var
- Check Dockerfile creates directory with correct permissions
- Use absolute paths, not relative

### "Environment variable not found"
**Causes:**
- Variable set in wrong service (if multi-service project)
- Typo in variable name
- App not redeployed after adding variable

**Fix:**
- Redeploy: **Deployments** → **...** → **Restart**
- Check variable scope (per-service vs project-wide)
- Log all env vars on startup to debug

### "Build failed"
**Causes:**
- Missing dependencies in package.json
- Dockerfile errors
- Build timeout (default 10min)

**Fix:**
- Read build logs carefully
- Test Dockerfile locally first: `docker build -t test .`
- Optimize build (use layer caching, minimize steps)

### "Out of hours/credits"
**Causes:**
- Free tier: 500 hours/month (~20.8 days continuous)
- Multiple services count separately

**Fix:**
- Add credit card for pay-as-you-go (very cheap: ~$5-10/month typical)
- Delete and recreate project (resets free tier, but loses data)
- Use sleep/wake patterns for dev environments

## Updates and Management

### Update to latest code:
- **GitHub auto-deploy:** Push to branch → Railway rebuilds
- **Manual:** CLI: `railway up`

### Disable auto-deploy:
- **Settings** → **Triggers** → toggle off auto-deploy

### View logs:
```bash
# CLI
railway logs

# Dashboard
Deployments tab → latest deployment → View Logs
```

### Restart service:
- **Deployments** → **...** → **Restart**
- Or redeploy via push to trigger branch

### Rollback:
- **Deployments** → find previous successful deploy → **...** → **Redeploy**

## Cost Structure (Free Tier)

✅ **Included free:**
- 500 execution hours/month
- $5 usage credit
- 100GB bandwidth out
- 100GB bandwidth in
- Unlimited projects

**Typical usage:**
- Single always-on service: ~730 hours/month (exceeds free tier by ~230 hours)
- Pay-as-you-go after free tier: ~$0.01/hour = ~$2.30/month overage
- With $5 credit: effectively free for small apps

## Multi-Service Projects

For apps with multiple containers (app + database + worker):

1. **New Service** → add Redis, PostgreSQL, etc.
2. Railway provides service URLs via env vars automatically:
   ```
   REDIS_URL=redis://redis.railway.internal:6379
   DATABASE_URL=postgresql://postgres.railway.internal:5432/db
   ```
3. Each service can have separate volumes, env vars, and scaling

## References

- Railway Docs: https://docs.railway.app
- Railway Discord: https://discord.gg/railway
- Example deployments: see `references/` directory
