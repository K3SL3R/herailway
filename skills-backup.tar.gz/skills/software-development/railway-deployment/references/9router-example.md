# 9Router Railway Deployment Example

Real-world deployment of 9router (AI model router/proxy) to Railway.app.

## Project Overview

**Repository:** https://github.com/decolua/9router  
**Purpose:** OpenAI-compatible AI router with smart fallback, token optimization, multi-provider support  
**Architecture:** Next.js web dashboard + Express proxy server + SQLite database  
**Port:** 20128  
**Storage:** Requires persistent volume for SQLite database

## Environment Variables

```bash
# Security (REQUIRED)
JWT_SECRET=<64-char-random-hex>
INITIAL_PASSWORD=<secure-password>

# Storage (REQUIRED)
DATA_DIR=/app/data

# Server config (REQUIRED)
PORT=20128
NODE_ENV=production
HOSTNAME=0.0.0.0

# Optional security
API_KEY_SECRET=<random-string>
MACHINE_ID_SALT=<random-string>
ENABLE_REQUEST_LOGS=false
OBSERVABILITY_ENABLED=true
AUTH_COOKIE_SECURE=false
REQUIRE_API_KEY=false
```

## Railway Configuration

### Dockerfile
Already present in repository. Key sections:
- Multi-stage build (builder + runner)
- Node 22 Alpine base
- Creates `/app/data` directory for volume
- Exposes port 20128
- Custom entrypoint for permission handling

### Volume Setup
- **Mount Path:** `/app/data`
- **Size:** 1GB (sufficient for SQLite + config)
- **Purpose:** Stores:
  - `db/data.sqlite` - main database
  - `db/backups/` - automatic backups
  - certificates, logs, runtime configs

### Networking
- Generate public domain for web dashboard access
- Dashboard: `https://<app>.up.railway.app/dashboard`
- API endpoint: `https://<app>.up.railway.app/v1`

## Deployment Steps

1. **Fork repository** to your GitHub account
2. **Railway: New Project** → Deploy from GitHub repo
3. **Add Variables** (copy from above)
4. **Add Volume:** mount path `/app/data`, 1GB
5. **Generate Domain** in Settings → Networking
6. **Wait for build** (3-5 minutes)
7. **Access dashboard** at generated URL

## Post-Deployment Setup

### Initial Login
- Navigate to dashboard URL
- Password: value of `INITIAL_PASSWORD` env var
- First action: change password in dashboard settings

### Configure Providers
Dashboard → Providers → Add free providers:
- **Kiro AI** - free Claude unlimited
- **OpenCode Free** - no auth required
- **iFlow** - free tier
- **Qwen** - free tier

### Use with CLI Tools
Point any OpenAI-compatible tool to:
```
Base URL: https://<your-app>.up.railway.app/v1
API Key: [get from dashboard settings]
```

Examples:
- Claude Code, Codex, Cursor, Cline
- OpenAI Python SDK: `OpenAI(base_url="https://...")`
- Any tool supporting OpenAI API format

## Common Issues

### "Application failed to respond"
**Symptom:** Railway shows active but URL times out  
**Cause:** Missing `HOSTNAME=0.0.0.0` or volume not mounted  
**Fix:** 
- Add `HOSTNAME=0.0.0.0` to Variables
- Verify volume mount path is exactly `/app/data`
- Restart deployment

### "Database error" in logs
**Symptom:** App crashes with SQLite errors  
**Cause:** Volume not properly mounted or permissions issue  
**Fix:**
- Check volume mount path matches `DATA_DIR` env var exactly
- Dockerfile creates `/app/data` and sets ownership correctly
- Redeploy to trigger permission fix in entrypoint.sh

### Cannot login to dashboard
**Symptom:** Wrong password or JWT errors  
**Cause:** Missing or changed JWT_SECRET, wrong INITIAL_PASSWORD  
**Fix:**
- Verify `JWT_SECRET` is set and is 32+ characters
- Double-check `INITIAL_PASSWORD` value
- Restart deployment after variable changes

## Resource Usage

**Observed metrics:**
- Memory: 150-250MB typical, 400MB peak
- CPU: <5% idle, 10-20% under load
- Disk: 50-200MB for database
- Network: Depends on API usage

**Free tier fit:** Easily runs within Railway free tier limits.

## Update Workflow

1. Original repo updates → fork gets behind
2. GitHub: Sync fork (pull upstream changes)
3. Railway: Auto-detects push, rebuilds automatically
4. Monitor Deployments tab for build status
5. Volume persists data through rebuilds

## Security Notes

- `JWT_SECRET` must be cryptographically random (use `crypto.randomBytes(32).toString('hex')`)
- Change `INITIAL_PASSWORD` immediately after first login
- Consider enabling `REQUIRE_API_KEY=true` for production
- Use `AUTH_COOKIE_SECURE=true` if behind HTTPS (Railway provides HTTPS by default)
- Regularly backup SQLite database (stored in volume)

## Integration Example

Using deployed 9router with Claude Code:

```bash
# ~/.config/claude-code/config.json
{
  "api_base": "https://my-9router.up.railway.app/v1",
  "api_key": "9r_xxxxxxxxxxxxx",
  "model": "kr/claude-sonnet-4"
}
```

Result: Claude Code uses free Kiro AI backend through 9router, never hits rate limits.
