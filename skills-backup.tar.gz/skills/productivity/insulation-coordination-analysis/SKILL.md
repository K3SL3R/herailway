---
name: insulation-coordination-analysis
description: Perform and analyze substation insulation coordination studies using DIgSILENT PowerFactory EMT simulation.
version: 0.1.0
author: Hermes
metadata:
  hermes:
    tags: [Substation, Insulation, Electrical, Transients, Surge-Arresters, Power-Systems]
    related_skills: [ocr-and-documents, systematic-debugging]
---

# Substation Insulation Coordination Analysis & Simulation

This skill guides the design, modeling, simulation, review, extraction, and verification of high-voltage substation insulation coordination studies (performed in DIgSILENT PowerFactory, PSCAD, or EMTP-RV). It provides both a structured methodology to parse technical PDF reports and detailed modeling guidelines to perform active EMT (Electromagnetic Transients) simulations, modeling lightning overvoltages (shielding failure and back-flashover), switching overvoltages, and surge arresters.

*For detailed PowerFactory EMT modeling parameters, curves, and formulas, see [references/powerfactory-emt-modeling.md](references/powerfactory-emt-modeling.md).*

## When to Use
- Designing and setting up an insulation coordination study in DIgSILENT PowerFactory.
- Reviewing an insulation coordination study report for a substation project (e.g. 400kV, 220kV, 132kV, 33kV) in PDF or spreadsheet (Excel) format.
- Extracting nominal/highest system voltages, equipment BIL (Basic Lightning Impulse Insulation Level) and SIL (Switching Impulse Insulation Level).
- Auditing surge arrester selections (Ur, Uc/MCOV, discharge class, residual voltages, temporary overvoltages).
- Verifying peak lightning and switching transient overvoltages from simulation cases (Shielding Failure, Back-Flashover, Switching, TOV) against equipment withstand levels.
- Extracting stray capacitances and line/cable models for substation EMT studies.
- **Excel-based deterministic review:** Auditing a conventional IEC 60071-2 coordination spreadsheet (no EMT simulation) for arithmetic errors, wrong Um, contradictory cells, and chain-of-calculation issues.

## Prerequisites
- PyMuPDF (`fitz`) for PDF extraction: `uv pip install pymupdf`.
- **openpyxl** for Excel (.xlsx) review: `uv pip install openpyxl`.
- Access to the insulation coordination study file (PDF or .xlsx) on the local filesystem.
- Optional: NumPy for cross-checking separation-effect arithmetic.

## How to Run
- **Active Simulation (DIgSILENT PowerFactory):** Configure high-frequency lines, non-linear tower footing resistance, stray capacitances, and surge arresters. Write Python automation scripts or run studies interactively using the PowerFactory EMT module.
- **Report Analysis & Auditing:** Invoke extraction and analysis of a study PDF through the `terminal` tool or inline python code with `execute_code`.
- **Excel Deterministic Review:** Load the .xlsx with openpyxl in data_only=False mode to inspect formulas, then data_only=True to see computed values. Trace every cross-sheet reference. Verify Um against IEC 60071-1 Table 2, then re-calculate the chain: Um → Um/√3 → TOV → Uc check → Urp → Urw → LIWV selection → protective ratios.
- **Excel Study Enhancement:** When user provides an incomplete deterministic Excel study (typically 40-50% complete with basic System Data, Withstand, Arrester sheets only), ADD missing advanced analysis sheets incrementally using openpyxl to reach 75-80% completeness. Create 6 core advanced sheets: Energy Stress, Tower & Line, Overvoltage Scenarios, High-Frequency Parameters, Statistical Coordination, and Cable Coordination. See `references/excel-advanced-sheets.md` for structure and formulas. Save after each sheet to avoid timeout.

## Quick Reference
- Standard Equipment Voltages ($U_n$ / $U_m$): e.g., 400kV / 420kV, 220kV / 245kV, 132kV / 145kV, 33kV / 36kV.
- Insulation Levels: BIL (Lightning Impulse Withstand Voltage), SIL (Switching Impulse Withstand Voltage), TOV (Temporary Overvoltage).
- Surge Arrester (SA) Parameters: Rated Voltage ($U_r$), Continuous Operating Voltage ($U_c$ or MCOV), Nominal Discharge Current ($I_n$, e.g., 20kA), Discharge Class (Class 4/5).

## Procedure

- **Finding Open Source Resources:** Use GitHub search for 'insulation coordination' or 'surge arrester modeling'. Repository `christosgoun/Insulation-Coordination-ATP` contains ATP/EMTP projects and Greek reports, while `arminking123/hvdc-insulation-coordination` provides a Python-based 5-step coordination calculator which is an excellent automated baseline for deterministic studies.
- **Downloading/Extracting:** If a repository contains a study in PDF or Excel (e.g. `ic_study_report.pdf` or `.xlsx`), use `terminal` to download it. If PDF parsing fails due to non-standard encoding, check if it's actually a repository of scripts or a malformed PDF; examine raw file contents with `head` or Python `base64` decoding.

### 2. Extract Equipment Insulation Withstand Ratings
Locate tables containing equipment peak insulation ratings (BIL, SIL, and power frequency withstand) for all voltage levels (GIS, outdoor switchyards, transformers, and cables). Record:
- Lightning Impulse Withstand Voltage (BIL/LIWP) in kVp.
- Switching Impulse Insulation Withstand Voltage (SIWV/BSL) in kVp.
- Rated power frequency withstand voltage in kV rms (To Earth and Between Open Contacts).

### 2A. Systematic EMT Simulation Report Review (PowerFactory/PSCAD/EMTP)

For large EMT study reports (50-100+ pages with multiple study cases), use this structured page-by-page workflow:

**Phase 1: Document Structure Mapping (15-20 minutes)**
```python
import fitz
doc = fitz.open(pdf_path)
# Extract table of contents (typically page 2-3)
toc_page = doc[1]
toc_text = toc_page.get_text()
# Map section page numbers: Introduction, Standards, Simulation Model, 
# Study Cases, Conclusion, Annexures
```

**Phase 2: Standards & Input Data Verification (20-30 minutes)**
- Extract reference standards section → verify IEC 60071-1 edition (2019 is latest)
- Extract System Data tables → verify Um values against IEC 60071-1 Table 2
- Extract GIS/equipment insulation levels → record BIL/SIL for each voltage level
- Extract surge arrester parameters → record Ur, MCOV, discharge class, residual voltages

**Phase 3: Simulation Model Audit (30-40 minutes)**
- Grid strength & short-circuit levels
- Overhead line model: conductor type, bundle spacing, tower geometry, earth resistivity
- EMT line model: distributed parameter vs. lumped, frequency-dependent
- Tower model: surge impedance (typical 80-120Ω), major/minor sections, grounding resistance
- Insulator flashover model: voltage-time curve, CFO voltage, capacitance (typical 20pF)
- GIS busduct model: conductor radius, enclosure, SF6 permittivity, stray capacitances
- Transformer model: leakage inductance, stray capacitances (HV-LV, HV-E, LV-E)
- Cable model: single-core geometry, conductor/sheath/insulation layers, semiconducting screens
- **Surge arrester model:** U-I characteristic curves, energy capability

**Phase 4: Study Case Results Verification (40-60 minutes)**
Review each study case in sequence (order matters for narrative):
1. **Shielding Failure I (no SA):** Establish baseline overvoltages without protection
2. **Shielding Failure II (with SA):** Verify SA limits overvoltages, check energy discharge
3. **Back-Flashover I (no SA):** Tower strike, insulator flashover, baseline stress
4. **Back-Flashover II (with SA):** Verify SA protection, check energy discharge
5. **Switching Overvoltage:** 3-phase fault clearing, verify peak < SIL
6. **Temporary Overvoltage:** Single-phase-to-ground fault, verify peak < SA TOV capability
7. **Critical Back-Flashover Current (optional):** Minimum strike current causing flashover

For each case, extract:
- Simulation parameters (strike current, wave shape, location, SA in/out of service)
- Peak overvoltages at critical nodes (GIS, transformer terminals, cable ends)
- SA currents and absorbed energy
- Protective margins: (BIL or SIL) / Peak_overvoltage - 1 ≥ 0.15 to 0.20

**Phase 5: MCOV Adequacy Diagnostic (Critical)**

For each voltage level, perform this diagnostic to verify surge arrester MCOV selection is adequate for system temporary overvoltage (TOV) during earth faults:

```python
import math

# Extract from report
Um = 145  # kV (highest system voltage from IEC 60071-1 Table 2)
Un = 132  # kV (nominal voltage)
MCOV = 86  # kV (from surge arrester specification)

# Calculate diagnostic ratios
ratio_MCOV_Um = MCOV / Um
ratio_MCOV_Un = MCOV / Un

# IEC 60071-1 requirement: MCOV ≥ Um/√3 × k
# where k = earth-fault factor
MCOV_min_effectively_earthed = Um / math.sqrt(3)  # k=1.0
k_max_supported = MCOV * math.sqrt(3) / Um

print(f"MCOV/Um = {ratio_MCOV_Um:.3f} ({ratio_MCOV_Um*100:.1f}%)")
print(f"MCOV/Un = {ratio_MCOV_Un:.3f} ({ratio_MCOV_Un*100:.1f}%)")
print(f"MCOV_min (effectively earthed) = {MCOV_min_effectively_earthed:.1f} kV")
print(f"Maximum earth-fault factor supported by MCOV={MCOV}kV: k={k_max_supported:.3f}")
```

**Interpretation guidelines:**
- **MCOV/Um = 80-84%:** Typical for effectively earthed systems (k≤1.4). Normal and adequate.
- **MCOV/Um = 59-65%:** Indicates either (a) effectively earthed system with conservative MCOV or (b) isolated/resonant earthed system. **FLAG FOR VERIFICATION.**
- **MCOV/Um < 58%:** Likely under-specified MCOV. Check TOV simulation results.

**Critical questions to ask user when MCOV/Um is low (<70%):**
1. Is the [voltage level] system effectively earthed according to OETC/utility standards?
2. What is the earth-fault factor (k) specified in the earthing design or grid code?
3. What was the maximum phase-to-ground voltage during the single-phase-to-ground fault simulation (TOV case)?
4. Was this surge arrester copied from a previous project with different earthing?

**Cross-check with TOV simulation:**
- Locate the "Single-Phase to Ground Short-Circuit – Temporary Overvoltage" study case
- Extract peak phase-to-ground voltage (in kVp) on healthy phases during fault
- Convert to RMS: TOV_rms = TOV_peak / √2
- Verify: TOV_rms ≤ SA_TOV_capability (1s or 10s rating from datasheet)
- If TOV_rms > MCOV, arrester will conduct continuously during fault → thermal failure risk

**Example findings to report:**
> "⚠️ 132kV Surge Arrester MCOV Adequacy Question:
> - MCOV = 86 kV, Um = 145 kV → MCOV/Um = 59.3%
> - This supports maximum earth-fault factor k = 1.027
> - IEC 60071-2 cl. 4.2: effectively earthed systems k ≤ 1.3
> - **If system is effectively earthed, MCOV=86kV is adequate (just barely)**
> - **If system is non-effectively earthed (k=1.4), require MCOV ≥ 117 kV**
> - **Action:** Verify earthing type with OETC standards and cross-check TOV simulation peak voltage"

*For complete MCOV adequacy diagnostic methodology, worked examples, and system earthing verification procedures, see [references/mcov-earthing-diagnostic.md](references/mcov-earthing-diagnostic.md).*

**Phase 6: Conclusion Cross-Check (10-15 minutes)**
- Extract final SA technical details table (typically last 10 pages)
- Verify Ur, MCOV, discharge class, energy capability match simulation model inputs
- Check conclusion statement: "surge arresters adequate to control overvoltages within equipment withstand levels"
- Flag any discrepancies between conclusion and actual simulation results

### 2B. Excel Deterministic Review Workflow (IEC 60071-2 spreadsheet audit)

When auditing a conventional deterministic coordination spreadsheet (no EMT simulation), follow this chain-of-calculation audit. Each step must be verified independently — a single upstream error (especially Um) invalidates all downstream values.

1. **Verify Um** against IEC 60071-1 Table 2. For a 132 kV system, Um = 145 kV (never 132). Record the discrepancy immediately.
2. **Re-compute Um/√3** and compare to the spreadsheet cell.
3. **Check TOV at arrester location:** TOV = (Um/√3) × earth-fault factor. Verify the factor (§ 4.2 says ≤1.3 for effectively earthed systems).
4. **Uc adequacy:** Required Uc ≥ Um/√3. If the spreadsheet Uc is below this, flag FAIL.
5. **TOV capability:** System TOV must be ≤ arrester TOV capability (10 s rating). If it fails, recommend upgrading Ur or verifying the factor with the client/utility.
6. **Separation-effect derivation:** Read the Urp-LI formula. For typical spreadsheet formulae, check for unexplained constants (e.g., ×100). Independently estimate ΔV:
   - Inductive: ΔV ≈ 2 · L' (µH/m) · La (m) · S (kA/µs)
   - Travelling wave: ΔV ≈ 2 · Z (Ω) · La (m) · S (kA/µs) / c (m/µs)
   Compare to spreadsheet result and flag large discrepancies.
7. **Altitude correction Ka:** Ka = exp(m·(H-1000)/8150) for H > 1000 m, else Ka = 1.0. Verify H matches site data, not a stale default.
8. **Required withstand:** Urw = Urp × Kcd × Ks × Ka. Check Kcd (typically 1.0 deterministic) and Ks (1.05 external, 1.15 internal per cl. 7.3.5).
9. **LIWV selection:** Verify the selected standard LIWV (IEC 60071-1 Table 2 row) ≥ Urw-LI. Standard values for Um=145 kV: 450, 550, 650 kV.
10. **Protective ratios:** PR-LI = LIWV / Upl-eff ≥ 1.20; PR-SI = SIWV / Ups ≥ 1.15.
11. **Creepage distance:** L_creep = Um × USCD. Cross-check the pollution class label against the USCD number actually used.
12. **Air clearances:** Per IEC 60071-2 Table A.1. For LIWV=650 kV: P-E=1300 mm, P-P=1500 mm.
13. **Chain-verification:** Load the spreadsheet with openpyxl(data_only=False) to read formulas, then data_only=True to read cached values. Compare each computed node against your independent re-calculation. Flag every discrepancy.

*For a worked example with full chain-of-calculation, see [references/iec-60071-deterministic-audit.md](references/iec-60071-deterministic-audit.md).*

### 2C. Excel Study Enhancement Workflow (adding advanced analysis sheets)

When user asks to complete/enhance an incomplete Excel study (typically 40-50% complete with only basic sheets), add 6 advanced analysis sheets incrementally. This brings coverage to 75-80% without requiring EMT simulation.

**Core advanced sheets (add in this order):**
1. **Energy Stress** — arrester energy absorption (lightning multi-stroke + switching duty)
2. **Tower & Line** — back-flashover analysis (Rg, Zt, CFO, tower voltage)
3. **Overvoltage Scenarios** — summary table of all L/S/TOV cases with PASS/FAIL
4. **High-Frequency** — CORRECT GIS L'=0.25 µH/m (not 1.0!), stray capacitances, reflections
5. **Statistical** — IEC Annex C Risk of Failure calculation (optional, advanced)
6. **Cable Coordination** — line-cable reflection, sealing end arrester (if applicable)

**Implementation pattern:**
- Load workbook with openpyxl.load_workbook(path)
- Create each sheet with wb.create_sheet(name, index)
- Add formulas with cross-sheet references (e.g., `='System Data'!E18`)
- Yellow fill for user inputs, green fill for corrected values
- **Save after each sheet** (avoids timeout)

*For detailed structure, formulas, and parameters for each sheet, see [references/excel-advanced-sheets.md](references/excel-advanced-sheets.md).*

### 3. Extract Surge Arrester Design Parameters
Locate the "Surge Arresters" modelling section and the concluding "Technical Details" tables. Document the following parameters for each voltage level:
- Manufacturer and model (e.g., Siemens, Sieyuan, ABB).
- Rated Voltage ($U_r$) and Maximum Continuous Operating Voltage ($U_c$ / MCOV).
- Nominal discharge current ($I_n$, typical 10kA or 20kA, 8/20 µs wave).
- IEC/ANSI discharge class (e.g., Class 4 or 5).
- Temporary Overvoltage (TOV) withstand curves (1s and 10s limits).
- Residual voltages at switching impulse (1kA, 2kA, 3kA) and lightning impulse (10kA, 20kA, 40kA).

### 4. Audit Transient Simulation Cases
Analyze the EMTP study case configurations. Document the simulation parameters:
- **Lightning Overvoltage (Shielding Failure):** Peak strike current (typical 20kA), wave shape (1.2/50 µs), conductor struck, and whether SAs are in-service.
- **Lightning Overvoltage (Back-Flashover):** Peak tower-top strike current (typical 200kA), wave shape (4/80 µs), tower struck, and tower grounding impedance (typical 10 to 15 $\Omega$).
- **Switching Overvoltage:** Three-phase short-circuit and clearing events, line energization, breaker pole-span timing, and SAs in-service.
- **Temporary Overvoltage (TOV):** Single phase to ground fault duration, system grounding coefficient, and peak power-frequency overvoltage.

### 5. Verify Insulation Coordination and Margin of Safety
Perform the verification checklist for insulation coordination safety margins:
- **Lightning Impulse Margin:** Compare peak simulated overvoltage ($U_{ps}$) against equipment BIL.
  $$\text{Margin of Safety} = \left( \frac{\text{BIL}}{U_{ps}} - 1 \right) \times 100\% \ge 20\% \quad (\text{IEC/IEEE standard})$$
- **Switching Impulse Margin:** Compare peak simulated overvoltage against equipment SIL.
  $$\text{Margin of Safety} = \left( \frac{\text{SIL}}{U_{ps}} - 1 \right) \times 100\% \ge 15\% \quad (\text{IEC/IEEE standard})$$
- **Surge Arrester Thermal Energy Adequacy:** Verify that the maximum absorbed energy in SAs during transients is well within the manufacturer's rated energy capability (in kJ or kJ/kV).
- **Temporary Overvoltage (TOV) Adequacy:** Ensure the system temporary overvoltage under single-phase earth faults does not exceed the surge arrester TOV capability curve for the given fault clearing time (e.g., 1 sec or 10 sec).

## Important Pitfall: Downloading Repositories for Scripts
When attempting to use Python scripts from GitHub repositories for engineering studies:
1. **Never assume a repository's `main` branch contains clean, runnable code.** Files may be mislabeled (e.g., a PDF named `.py`), encoded with legacy characters (latin-1/cp1252 instead of UTF-8), or lack essential dependencies.
2. **Verify File Content Immediately:** Before attempting to `import` or execute any downloaded `.py` file, check its actual content using `head` or `read_file` to ensure it is valid Python code and not a binary format (like PDF, despite the extension).
3. **Handle Encoding:** If code contains non-UTF-8 characters, read/write with `encoding='latin-1'` or `errors='replace'` to fix the file locally before execution.
4. **Prefer Deterministic Tools:** For insulation coordination, prefer building custom, standard-compliant Python scripts based on IEC 60071-2 rather than relying on unverified, potentially incomplete third-party GitHub "engine" code.

1. **Wrong Um from IEC 60071-1 Table 2 — #1 fatal error in deterministic reviews.** For a 132 kV system, Um = 145 kV, NOT 132 kV. The same mistake appears at other levels too: 33 kV → Um=36 kV, 220 kV → Um=245 kV, 400 kV → Um=420 kV. Always verify Um against the standard, never trust the spreadsheet cell. This single error radiates through Um/√3, TOV, creepage, required Uc, and protective-ratio margins in a chain reaction.
1a. **MCOV inadequacy not diagnosed — critical for EMT report review.** When reviewing surge arrester selections in EMT simulation reports, always calculate MCOV/Um ratio. Normal range is 80-84% for effectively earthed systems. If MCOV/Um < 70%, flag for verification: (a) check system earthing type with utility standards, (b) verify earth-fault factor k from earthing design, (c) cross-check TOV simulation peak voltage against SA TOV capability. Example: 132kV system with Um=145kV and MCOV=86kV gives ratio=59.3%, which supports only k≤1.027 — adequate for effectively earthed (k≤1.3) but inadequate if k=1.4. See Phase 5 diagnostic procedure for full methodology.
2. **Misidentifying PDF Page Numbers:** Standard document page numbers (e.g., "Page 35 of 83") are often offset from the physical PDF file page indexes due to title sheets. Always compute the offset before batch extracting pages.
3. **Ignoring Stray Capacitances:** High-frequency transients are highly sensitive to stray capacitances. When reviewing the model setup, ensure GIS busducts, bushings, CTs, and transformer windings include stray capacitances (e.g., typical 80pF for SAs).
4. **Comparing Peak to RMS:** Ensure simulated overvoltage peaks (kVp) are compared to the peak withstand ratings (BIL/SIL), and never directly to RMS system voltages without proper scaling.
5. **Ignoring SAs Out-of-Service Cases:** Shielding failure and back-flashover studies are often run *without SAs* to demonstrate the necessity of protection (showing flashover/equipment damage), then rerun *with SAs* to prove protection adequacy.
6. **Pollution class / USCD mismatch.** Common error: cell says "Very Heavy" (Class d, USCD ≥ 31 mm/kV) but uses USCD = 25 (Class c / Heavy). Cross-check label against the numeric value.
7. **AIS/GIS header confusion.** Filename may say "GIS" while every page header says "AIS". GIS and AIS differ in stray capacitances, bus impedance, and clearance tables. Clarify with project docs.
8. **Altitude correction misapplied.** IEC 60071-2:2023 Eq. 11: Ka = exp(m·(H-1000)/8150) for H > 1000 m. For H ≤ 1000 m, Ka = 1.0. If a comment says H=300 m but data says H=1000 m, flag it.
9. **Earth-fault factor assumption.** IEC 60071-2 cl. 4.2 says effectively earthed systems ≤ 1.3. If spreadsheet uses 1.4, verify against earthing design and local utility standard (e.g., OETC-AMD-O-AMT-M-040 in Oman).
10. **Separation-effect formula has unexplained ×100 factor.** Derive independently: ΔV = 2·L'·La·S (inductive) or ΔV = 2·Z·La·S/c (travelling wave). If result differs, flag methodology.
11. **GIS inductance wrong (L' = 1.0 µH/m).** Basic deterministic sheets often copy-paste overhead line inductance (1.0 µH/m) for GIS installations. CORRECT value for GIS: L' = 0.2-0.3 µH/m (enclosed conductor in SF6). This error propagates to separation-effect voltage (ΔV = 2·L'·La·S), inflating Upl-effective by 300-400%. When reviewing GIS studies, always verify L' against manufacturer specs or use 0.25 µH/m as conservative default. Flag in high-frequency analysis sheet.

## Verification Checklist
- [ ] Equipment nominal ($U_n$) and rated highest system voltages ($U_m$) extracted for all voltage tiers.
- [ ] Equipment peak insulation withstand ratings (BIL/SIL) documented.
- [ ] Surge arrester technical parameters ($U_r$, $U_c$, $I_n$, Class, Residual voltages) cataloged.
- [ ] **MCOV adequacy verified:** For each voltage level, MCOV/Um ratio calculated and interpreted (normal 80-84%, flag if <70%).
- [ ] **Earth-fault factor verified:** System earthing type confirmed with utility standards, k value documented.
- [ ] **TOV simulation cross-check:** Peak phase-to-ground voltage from single-phase fault case ≤ SA TOV capability.
- [ ] Simulation cases (Lightning, Switching, TOV) parameters and wave shapes documented.
- [ ] Peak simulated overvoltages ($U_{ps}$) at critical nodes (GIS, Transformer, Cable Sealing End) tabulated for in-service SA cases.
- [ ] Margin of safety calculated and verified ($\ge 20\%$ for lightning, $\ge 15\%$ for switching).
- [ ] Surge arrester energy discharge verified within rated limits.
- [ ] Temporary overvoltage compared to surge arrester TOV withstand capability.
- [ ] **Excel deterministic review (when applicable):**
  - [ ] Um verified against IEC 60071-1 Table 2 (not blindly copied from cell)
  - [ ] Um/√3 and TOV re-calculated independently
  - [ ] Earth-fault factor justified (≤1.3 for effectively earthed) or flagged
  - [ ] Uc ≥ Um/√3 verified
  - [ ] TOV capability ≥ system TOV verified
  - [ ] Separation effect formula audited — unexplained constants flagged
  - [ ] Ka formula correctly applied (Ka=1 for H≤1000 m)
  - [ ] LIWV ≥ Urw-LI and protective ratios (PR-LI≥1.20, PR-SI≥1.15) verified
  - [ ] Creepage: pollution class label matches USCD number used
  - [ ] All cross-sheet formula references traced — no stale cached values
