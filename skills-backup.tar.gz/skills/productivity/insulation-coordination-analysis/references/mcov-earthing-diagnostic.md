# MCOV Adequacy and System Earthing Diagnostic

This reference provides a systematic methodology to verify surge arrester Maximum Continuous Operating Voltage (MCOV / Uc) adequacy by analyzing the MCOV/Um ratio and cross-checking against system earthing type and temporary overvoltage (TOV) simulation results.

## Background

Per IEC 60071-1 and IEC 60099-5, surge arrester MCOV must be selected to withstand the maximum continuous power-frequency voltage that can appear across the arrester terminals, including during single-phase earth faults. The selection formula is:

```
MCOV ≥ Um / √3 × k
```

Where:
- **Um** = Highest system voltage for equipment (IEC 60071-1 Table 2)
- **k** = Earth-fault factor (ratio of highest phase-to-ground voltage to Um/√3 during earth fault)

For **effectively earthed systems** (IEC 60071-2 cl. 4.2):
- k ≤ 1.4 (typically 1.3 for solidly earthed systems)
- X₀/X₁ ≤ 3 and R₀/X₁ ≤ 1 (zero-sequence to positive-sequence impedance ratios)

For **non-effectively earthed systems** (isolated neutral, resonant earthed, impedance earthed):
- k can reach √3 = 1.732 (isolated neutral worst case)

## Diagnostic Procedure

### Step 1: Extract Parameters from Report

From surge arrester specification section:
- MCOV (kV rms)
- Ur (rated voltage, kV rms)

From system data section:
- Un (nominal voltage, kV)
- Um (highest system voltage, kV) - verify against IEC 60071-1 Table 2

### Step 2: Calculate MCOV/Um Ratio

```python
import math

Um = 145  # kV (for 132kV system per IEC 60071-1)
MCOV = 86  # kV (from surge arrester datasheet)

ratio = MCOV / Um
print(f"MCOV/Um = {ratio:.3f} = {ratio*100:.1f}%")

# Calculate minimum MCOV for effectively earthed (k=1.0)
MCOV_min = Um / math.sqrt(3)
print(f"MCOV_min (effectively earthed) = {MCOV_min:.1f} kV")

# Calculate maximum earth-fault factor this MCOV supports
k_max = MCOV * math.sqrt(3) / Um
print(f"Maximum k supported = {k_max:.3f}")
```

### Step 3: Interpret Ratio

| MCOV/Um Ratio | Interpretation | Action |
|---------------|----------------|--------|
| 80-84% | Normal for effectively earthed systems (k≈1.3-1.4) | Verify TOV simulation |
| 70-79% | Conservative for effectively earthed OR low-k system | Verify earthing type |
| 59-69% | Marginal - supports k≤1.1 only | **FLAG - verify earthing type and TOV** |
| <59% | Under-specified for most systems | **FAIL - recommend MCOV increase** |

### Step 4: Verify System Earthing Type

Check project specifications, utility grid code, or earthing design documents:

**For OETC (Oman Electricity Transmission Company):**
- Check OETC-AMD-O-AMT-M-040 (Earthing & Lightning Protection Standard)
- Check OETC Five-Year Transmission Capability Statement
- Verify neutral grounding resistor (NGR) or reactor specifications

**Common earthing types by voltage level:**
- **400kV, 220kV:** Typically solidly earthed (k≈1.3)
- **132kV:** Region-dependent (solidly earthed in many systems, k≈1.3)
- **33kV:** Often resistance or reactance earthed (k≈1.4)
- **11kV, 6.6kV:** Frequently resistance or resonant earthed (k>1.4)

### Step 5: Cross-Check TOV Simulation Results

Locate the "Single-Phase to Ground Short-Circuit – Temporary Overvoltage" study case in the EMT report.

**Extract:**
- Peak phase-to-ground voltage on healthy phases (kVp)
- Fault duration (typically 50-100 ms before clearing)

**Convert peak to RMS:**
```python
TOV_peak = 760  # kVp (from simulation waveform)
TOV_rms = TOV_peak / math.sqrt(2)
print(f"TOV (RMS) = {TOV_rms:.1f} kV")
```

**Compare to SA TOV capability:**
- From surge arrester datasheet, find TOV withstand at fault duration
- Example: "1 sec TOV = 116 kV, 10 sec TOV = 108 kV"
- Verify: TOV_rms ≤ SA_TOV_capability

**If TOV_rms > MCOV:**
- Arrester will conduct during fault
- If TOV_rms < SA_TOV_capability: acceptable temporary conduction
- If TOV_rms > SA_TOV_capability: **FAIL - thermal overload risk**

## Worked Example: 132kV System Review (MAJAN Project)

### Given Data
- System: 132kV nominal
- Um: 145 kV (IEC 60071-1 Table 2)
- Selected surge arrester: Siemens 3EQ4 108
  - Ur = 108 kV
  - MCOV = 86 kV
  - 1s TOV capability = 116 kV
  - 10s TOV capability = 108 kV

### Calculation
```python
Um = 145
MCOV = 86
ratio = MCOV / Um  # = 0.593 = 59.3%

MCOV_min_eff = Um / math.sqrt(3)  # = 83.7 kV
k_max = MCOV * math.sqrt(3) / Um  # = 1.027
```

### Interpretation
- **MCOV/Um = 59.3%** - LOW, in the marginal range
- MCOV = 86 kV slightly exceeds minimum 83.7 kV for effectively earthed
- Maximum k supported = 1.027

**Adequacy assessment:**
- ✅ **If system is effectively earthed (k≤1.3):** MCOV=86kV is adequate
- ❌ **If system is non-effectively earthed (k=1.4):** MCOV should be ≥117kV

### TOV Simulation Check
From report "Section 5.6 Single-Phase to Ground Fault":
- Peak voltage at 132kV terminals: 760 kVp (at 400kV side fault)
- This is for 400kV fault propagating to 132kV side through transformer

**Need to verify:**
- 132kV side TOV during 132kV bus single-phase fault
- If report doesn't include dedicated 132kV fault case, this is a gap

### Critical Questions for User
1. Is the 132kV OETC network effectively earthed per OETC standards?
2. What is the specified earth-fault factor in the earthing design?
3. Was there a dedicated TOV simulation for 132kV bus single-phase fault?
4. Was this surge arrester specification copied from a previous project?

### Recommendations
**If effectively earthed (k≤1.3):**
- MCOV=86kV is marginally adequate
- Recommend verifying with dedicated 132kV TOV simulation
- Document earthing type assumption in design basis

**If earthing type unconfirmed:**
- Recommend increasing to MCOV=108kV (Ur=132kV class arrester)
- This supports k≤1.57, providing margin for uncertainty
- Or request OETC earthing standard confirmation

## Common Scenarios

### Scenario 1: MCOV Too Low (Under-Specified)
**Symptoms:** MCOV/Um < 58%, k_max < 1.0
**Cause:** Wrong Um used in calculation, or arrester from different voltage system
**Action:** Recalculate with correct Um, or select higher Ur class arrester

### Scenario 2: MCOV Conservative (Over-Specified)
**Symptoms:** MCOV/Um > 85%, k_max > 1.5
**Cause:** Non-effectively earthed system (isolated or resonant earthed)
**Action:** Verify this matches system earthing design, document in report

### Scenario 3: MCOV Marginal (Borderline)
**Symptoms:** MCOV/Um = 59-69%, k_max = 1.0-1.2
**Cause:** Selection based on effectively earthed assumption without margin
**Action:** Request earthing type confirmation, perform TOV simulation verification

### Scenario 4: TOV Exceeds MCOV but Within Capability
**Symptoms:** TOV_rms > MCOV but < SA_TOV_capability(1s)
**Cause:** Earth fault causes temporary conduction through arrester
**Action:** Acceptable if TOV duration < arrester thermal limit (typically 1-10 seconds)

## Integration with Report Review Workflow

When reviewing EMT simulation reports, apply this diagnostic at **Phase 5** (after extracting SA parameters but before verifying simulation results):

1. Calculate MCOV/Um for all voltage levels (400kV, 220kV, 132kV, 33kV)
2. Flag any ratios outside normal range (80-84%)
3. Identify which voltage levels need earthing verification
4. When reviewing TOV simulation results, cross-reference peak voltages
5. Include MCOV adequacy findings in final review summary

## References
- IEC 60071-1:2019 - Insulation co-ordination Part 1: Definitions, principles and rules
- IEC 60071-2:2023 - Insulation co-ordination Part 2: Application guide (cl. 4.2 Earthing)
- IEC 60099-5:2018 - Surge arresters Part 5: Selection and application recommendations
- IEEE C62.22-2015 - Guide for Application of Metal-Oxide Surge Arresters for AC Systems
