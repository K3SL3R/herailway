# DIgSILENT PowerFactory EMT Modeling for Insulation Coordination

This reference covers the specific technical modeling parameters, standards, and transient simulation workflows in DIgSILENT PowerFactory for high-voltage substation insulation coordination (EMT studies).

## 1. High-Frequency Network Component Modeling

Standard $50\text{ Hz}$ modeling is insufficient for high-frequency transients. The following modeling conventions must be followed in PowerFactory:

### A. Transmission Overhead Lines (OHL)
* Use the **Frequency Dependent (Phase)** model (`ElmLne` with frequency-dependent parameters) or **Constant Parameter (J.Marti)** model. Standard lumped $\pi$-circuits fail to capture high-frequency attenuation and phase-coupling.
* Model individual tower structures explicitly for the first 3 to 5 spans adjacent to the substation.
* Model earth wires (shield wires) as dedicated coupled conductors.

### B. Substation Equipment Stray Capacitances
High-frequency surge propagation is heavily affected by stray capacitances. Model these as lumped capacitors to ground at relevant terminal junctions:

| Equipment / Node | Typical Stray Capacitance to Ground |
| :--- | :--- |
| **Capacitive Potential Transformer (CVT)** | $6000\text{ pF}$ |
| **Magnetic Potential Transformer (VT)** | $600\text{ pF}$ |
| **Current Transformer (CT)** | $350\text{ pF}$ |
| **Disconnector (open or closed)** | $120\text{ pF}$ |
| **Circuit Breaker** | $150\text{ pF}$ |
| **Bus Support Insulator** | $100\text{ pF}$ |
| **Transformer HV Winding (e.g., 220kV)** | $2700\text{ pF}$ |
| **Transformer MV Winding (e.g., 60-110kV)** | $2350\text{ pF}$ |
| **Transformer LV Winding (e.g., 11-33kV)** | $2000\text{ pF}$ |
| **Between Transformer Windings** | $30\text{ pF}$ |

### C. Surge Arresters (ElmArrester)
* Model as gapless metal-oxide surge arresters.
* Input the non-linear voltage-current (V-I) characteristic (residual voltage vs discharge current) for $8/20\ \mu\text{s}$ wave-shapes from the manufacturer's data sheets.
* Typical characteristic for a $220\text{ kV}$ arrester:
  * $0.1\text{ kA} \rightarrow 527.9\text{ kV}$
  * $1.0\text{ kA} \rightarrow 582.0\text{ kV}$
  * $10.0\text{ kA} \rightarrow 676.8\text{ kV}$ (Nominal discharge current)
  * $20.0\text{ kA} \rightarrow 730.0\text{ kV}$

### D. Tower Surge Impedance ($Z_T$)
Docks (towers) are modeled as short lossless distributed transmission lines with specific surge impedances based on geometric shape:
* **Conical Tower (Sargenet):**
  $$Z_T = 60 \ln \left( \frac{2}{\sin \theta} \right)$$
  where $\theta$ is the half-angle of the cone.
* **Cylindrical Tower:**
  $$Z_T = 60 \ln \left( \frac{h}{r} \right) - 60$$
  where $h$ is tower height, and $r$ is cylinder radius.

### E. Non-Linear Tower Footing Resistance ($R_i$)
To capture soil ionization during high-current lightning discharges, model tower footing resistance as a current-dependent non-linear resistor:
$$R_i = \frac{R_0}{\sqrt{1 + \frac{I_R}{I_g}}}$$
where:
* $R_0$ = Low-frequency/low-current grounding resistance (e.g., $10\ \Omega$ to $15\ \Omega$).
* $I_R$ = Lightning current passing through the footing resistance.
* $I_g$ = Soil ionization initiation current:
  $$I_g = \frac{1}{2\pi} \cdot \frac{\rho \cdot E_0}{R_0^2}$$
  * $\rho$ = Soil resistivity ($\Omega\cdot\text{m}$).
  * $E_0$ = Soil ionization gradient (typical value is $400\text{ kV/m}$).

---

## 2. Lightning Stroke Modeling (Heidler Function)

To inject lightning surges into the EMT simulation, use a time-dependent current source. The standard wave-shape model is the **Heidler Function**:

$$i(t) = \frac{I_0}{\eta} \cdot \frac{(t/\tau_1)^n}{1 + (t/\tau_1)^n} \cdot e^{-t/\tau_2}$$

### Typical Parameter Configurations (Heidler)
| Simulation Scenario | Peak Current ($I_{peak}$) | Wave-shape | Front Time ($T_1$) | Tail Time ($T_2$) | Factor ($\eta$) | Exponent ($n$) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Direct Phase Stroke** | $20\text{ kA}$ | $1.2/50\ \mu\text{s}$ | $0.75\ \mu\text{s}$ | $68.1\ \mu\text{s}$ | $0.98$ | $8$ |
| **AS 1768 Ideal Stroke** | $150\text{ kA}$ | $4.6/40\ \mu\text{s}$ | $3.95\ \mu\text{s}$ | $42.9\ \mu\text{s}$ | $0.88$ | $13$ |
| **250yr MTBF Design** | $112\text{ kA}$ | $2.5/91\ \mu\text{s}$ | $1.91\ \mu\text{s}$ | $122.3\ \mu\text{s}$ | $0.97$ | $13$ |

---

## 3. Core Simulation Cases in PowerFactory

### Case A: Shielding Failure (Direct Strike)
* **Goal:** Verify that lightning passing through the shield wire directly striking a phase conductor does not cause insulator flashover or damage equipment.
* **Setup:** Connect a $20\text{ kA}$ ($1.2/50\ \mu\text{s}$) Heidler source to the phase conductor at the first tower outside the substation. Ensure surge arresters are in-service.
* **Output:** Monitor peak voltages at the line entrance (gantry), circuit breakers, CTs, CVTs, and transformer bushings.

### Case B: Back-Flashover (BFO)
* **Goal:** Simulate a strike to the shield wire or tower-top that causes a flashover across the insulator string back to the phase conductor due to rise in tower potential.
* **Setup:** Apply a high-magnitude strike (e.g., $100\text{ kA}$ to $200\text{ kA}$) to the tower top. Model the insulator string using the time-dependent voltage-strength model:
  $$V_{strength}(t) = CFO + \frac{58.3 \cdot d}{t^{0.39}}$$
  where $d$ is insulator length (m), and $t$ is time ( $\mu\text{s}$).
* **Action:** Close a parallel circuit-breaker model representing the arc path once $V_{insulator} \ge V_{strength}$. High surge voltage then propagates down the phase line into the substation.

### Case C: Switching Overvoltages
* **Goal:** Assess slower overvoltages caused by breaker opening/closing, specifically three-phase line energization/reclosing.
* **Setup:** Use a larger integration step (e.g., $10\ \mu\text{s}$ to $50\ \mu\text{s}$). Model the breaker pole-span timing discrepancy (typical discrepancy: $2\text{ ms}$ to $5\text{ ms}$).

---

## 4. Safety Margins and Acceptance Criteria (IEC 60071-1)

Ensure your PowerFactory simulation results meet the following international safety margins:

1. **Lightning Overvoltages:**
   $$\text{Margin of Safety (LI)} = \left( \frac{\text{BIL}}{U_{ps}} - 1 \right) \times 100\% \ge 20\%$$
   * $\text{BIL}$ = Basic Lightning Impulse Insulation Level (peak withstand rating of equipment).
   * $U_{ps}$ = Peak simulated overvoltage at the equipment location during strike.

2. **Switching Overvoltages:**
   $$\text{Margin of Safety (SI)} = \left( \frac{\text{SIL}}{U_{ps}} - 1 \right) \times 100\% \ge 15\%$$
   * $\text{SIL}$ = Switching Impulse Insulation Level.

3. **Surge Arrester Energy Capability:**
   $$E_{absorbed} \le E_{rated}$$
   Ensure the total energy absorbed by the arrester model (in $\text{MW}\cdot\text{s}$ or $\text{kJ}$) is less than the manufacturer's maximum thermal rating.
