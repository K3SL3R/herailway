# Excel Advanced Analysis Sheets for Insulation Coordination Studies

This reference documents the 6 advanced analysis sheets that transform an incomplete deterministic Excel study (40-50% complete) into a comprehensive study (75-80% complete). These sheets add depth beyond basic System Data, Withstand, and Arrester sheets.

## Overview

**Target audience:** Engineers completing IEC 60071-2 deterministic coordination spreadsheets for 132kV-400kV GIS/AIS substations.

**Typical baseline:** 7 sheets (Standards, System Data, Withstand, Clearance, Arrester, Coordination, Summary)

**Enhancement:** Add 6 advanced sheets to cover energy stress, back-flashover, scenarios, high-frequency corrections, statistical methods, and cable coordination.

**Coverage increase:** 40-45% → 75-80% (EMT simulation still required for 100%)

---

## Sheet 1: Energy Stress Analysis

**Purpose:** Verify surge arrester energy absorption capability against lightning/switching duty.

**Key sections:**
1. Arrester energy capability (from datasheet or estimated)
2. Lightning energy absorption (single + multi-stroke)
3. Switching energy absorption
4. Thermal duty cycle analysis

**Critical formulas:**

```
Single impulse capability: W_single = 5.5 kJ/kV × Ur  (typical)
Lightning stroke energy: W_lightning = K × Ur × I_peak
  where K ≈ 28 for 8/20 µs waveform
Multi-stroke total: W_total = W_first + N × W_subsequent
  where W_subsequent ≈ 0.5 × W_first
Thermal factor: exp(-t_cooling / τ)
  where τ ≈ 10-15 min for MO arresters
```

**Cross-references:**
- Ur from System Data sheet
- I_lightning from Tower & Line sheet (if present) or assume 100 kA

**Outputs:**
- Energy margin = W_capability / W_absorbed (should be > 1.0)
- Status: PASS/FAIL

---

## Sheet 2: Tower & Line Parameters

**Purpose:** Provide back-flashover analysis for overhead line connections.

**Key sections:**
1. Tower geometry and grounding (H, Rg, Zt, L_tower)
2. Insulator string data (CFO dry/wet)
3. Lightning current parameters (IEC 62305)
4. Line surge impedance
5. Back-flashover voltage calculation

**Critical formulas:**

```
Tower voltage: V_tower = V_R + V_L
  V_R = I × Rg  (resistive drop)
  V_L = L_total × (dI/dt)  (inductive drop)
  L_total = H_tower × L'_tower  (typically 1.5 µH/m)

Back-flashover margin: CFO_wet / V_tower
  CFO_wet ≈ 0.85 × CFO_dry
  Target margin > 1.0 (else tower footing or insulation upgrade needed)

Current steepness: dI/dt = I_peak / t_front
  For 100 kA, 1.2 µs: dI/dt ≈ 83 kA/µs
```

**Key parameters (yellow fill = user input):**
- H_tower: 15-25 m typical
- Rg: Target <20Ω (IEC 62305), <10Ω for critical substations
- Zt: 150-250Ω typical steel tower
- CFO: ~70 kV/disc for porcelain, ~60 kV/disc for composite (LI)
- I_peak: 10 kA (median), 100 kA (95%), 200 kA (max design)

**Outputs:**
- V_tower at 95% lightning (typically 2000-5000 kV)
- Back-flashover risk: LOW if margin > 1.0, HIGH otherwise

---

## Sheet 3: Overvoltage Scenarios

**Purpose:** Summarize all overvoltage cases in a single reference table.

**Structure:** Table with columns:
- Scenario ID (L1-L3, S1-S4, T1-T3)
- Case description
- Peak overvoltage (kV)
- Duration (µs or s)
- BIL/Status (PASS/FAIL vs equipment withstand)

**Scenario categories:**

**Lightning (L1-L3):**
- L1: Back-flashover (from Tower & Line sheet)
- L2: Shielding failure (direct strike, typically 5000-10000 kV without arrester)
- L3: GIS terminal with arrester (Upl-eff from Arrester sheet)

**Switching (S1-S4):**
- S1: Line energization uncontrolled (2.5-3.0 pu, typically 280-350 kV)
- S2: Line energization controlled (1.8-2.3 pu)
- S3: Fault clearing TRV (transient recovery voltage)
- S4: Capacitor/reactor switching

**TOV (T1-T3):**
- T1: Single-phase earth fault 1s (from System Data TOV)
- T2: Single-phase earth fault 10s (same or slightly lower)
- T3: Loss of neutral (Um for unearthed systems)

**Cross-references:**
- Lightning scenarios: Tower & Line, Arrester sheets
- Switching: assume 2.5-3.0 pu or link to simulation
- TOV: System Data sheet

**Summary section (text bullets):**
- Lightning: Back-flashover critical if Rg > 20Ω
- Lightning: Shielding failure requires line arrester
- Switching: Uncontrolled may exceed SIWV → recommend controlled switching
- TOV: Verify earth-fault factor with utility standard

---

## Sheet 4: High-Frequency Parameters

**Purpose:** CORRECT the GIS inductance error and add stray capacitances.

**Critical correction:**

```
WRONG (common in basic sheets): L'_GIS = 1.0 µH/m  (overhead line value!)
CORRECT for GIS: L'_GIS = 0.2-0.3 µH/m  (enclosed conductor in SF6)
```

**Key sections:**
1. GIS parameters CORRECTED (L', C', Z_GIS)
2. Corrected separation effect calculation
3. Stray capacitances (CT, VT, bushing)
4. Reflection coefficients at junctions

**Critical formulas:**

```
GIS surge impedance: Z_GIS = √(L'/C')
  L' = 0.25 µH/m, C' = 60 pF/m → Z ≈ 64Ω  (typical)

OLD separation voltage (WRONG):
  δV = 2 × 1.0 × La × S = 2 × La × S  (µH/m assumed 1.0)

CORRECTED separation voltage:
  δV = 2 × 0.25 × La × S  (75% reduction!)

Reflection coefficient at junction:
  ρ = (Z2 - Z1) / (Z2 + Z1)
  Voltage multiplication: 1 + ρ
```

**Stray capacitances (typical 132kV):**
- CT: 200-300 pF
- VT: 100-200 pF
- Transformer bushing C1: 3000-5000 pF
- Transformer bushing C2: 500-1000 pF

**Outputs:**
- Comparison: OLD vs CORRECTED Upl-effective
- Improvement (kV reduction)
- Reflected voltage at junctions

**Styling note:** Use green fill for corrected values, show old value in adjacent row for comparison.

---

## Sheet 5: Statistical Coordination

**Purpose:** IEC 60071-2 Annex C advanced method for optimized insulation selection.

**Key sections:**
1. Overvoltage distribution (log-normal for lightning)
2. Equipment withstand distribution (normal)
3. Risk of Failure (RF) calculation
4. Statistical coordination factor (Kcs)
5. Deterministic vs statistical comparison

**Critical formulas:**

```
Log-normal overvoltage (lightning):
  P(U > U_x) = 1 - Φ[(ln(U_x) - ln(μ)) / (σ/μ)]
  90% overvoltage: U_90 = μ × exp(1.28 × COV)
  95% overvoltage: U_95 = μ × exp(1.64 × COV)
  99% overvoltage: U_99 = μ × exp(2.33 × COV)
  where COV = σ/μ

Normal withstand (equipment):
  U_50% = BIL / 1.15  (conventional 50% withstand)
  σ_eq = 0.03 × BIL  (3% standard deviation typical)

Risk of Failure:
  RF = P(overvoltage > U_50%) × (1 - P_withstand at U_50%)
  Target: RF < 1% (IEC recommendation)

Statistical coordination factor:
  Kcs = U_95% / μ  (vs deterministic Kcd = 1.0)
  Potential BIL reduction: (Kcd - Kcs) × μ
```

**Key parameters (yellow fill):**
- μ (mean lightning OV): 350-450 kV typical for 132kV with arrester
- σ (std dev): 80-120 kV (20-30% of mean)
- BIL: from Withstand sheet

**Outputs:**
- RF percentage (ACCEPTABLE if < 1%, else NEEDS IMPROVEMENT)
- Alternative BIL (statistical): U_95 × 1.15
- Potential savings vs deterministic approach

**Note:** This is OPTIONAL enhancement. Basic studies use deterministic only.

---

## Sheet 6: Cable Coordination

**Purpose:** Insulation coordination for underground cable sections (if applicable).

**Key sections:**
1. Cable parameters (type, length, BIL, Z_cable)
2. Line-cable junction reflection analysis
3. Cable sealing end arrester sizing
4. Sheath overvoltage protection (SVL)

**Critical formulas:**

```
Reflection coefficient at line-cable junction:
  ρ = (Z_cable - Z_line) / (Z_cable + Z_line)
  Typical: (40 - 450) / (40 + 450) = -0.84  (large negative!)

Voltage at cable entry:
  V_cable = V_incident × (1 + ρ) = V_incident × 0.16  (reduction)

Reflected wave back to line:
  V_reflected = V_incident × (1 - ρ) = V_incident × 1.84  (increase!)
  → Line arrester may be needed

Cable arrester margin:
  PR-LI = BIL_cable / Upl_arrester ≥ 1.20
```

**Key parameters (yellow fill):**
- Cable type: XLPE 132kV typical
- Cable length: 100-5000 m
- Z_cable: 30-50Ω typical
- BIL_cable: 650-750 kV for 132kV XLPE
- Bonding type: Solid / Cross-bonded / Single-point

**Outputs:**
- Reflection coefficient and voltage multiplication
- Cable arrester requirement (YES if length > 100m)
- SVL requirement (YES for cross-bonded)

**Notes section (text bullets):**
- Cable arrester required at sealing end if cable length > 100m
- Overhead line arrester may be needed due to high reflected wave
- SVL (Sheath Voltage Limiter) required for cross-bonded configuration
- Cable BIL should match or exceed overhead equipment BIL

---

## Implementation Pattern (openpyxl)

**Workflow:**
1. Load existing workbook with openpyxl.load_workbook()
2. Create each sheet incrementally with wb.create_sheet(name, index)
3. Add headers (document NO, revision, page N of M)
4. Add section titles with bold font
5. Add data rows with formulas (yellow fill for user inputs)
6. **Save after each sheet** (avoids timeout)
7. Repeat for all 6 sheets

**Styling helpers:**
```python
from openpyxl.styles import Font, PatternFill

yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
title_font = Font(name='Arial', size=14, bold=True)
header_font = Font(name='Arial', size=11, bold=True, color="FFFFFF")
```

**Formula best practices:**
- Cross-sheet references: `='System Data'!E18`
- IF conditions: `=IF(E27>=1.2,"PASS","FAIL")`
- Math functions: `=SQRT(E9/E10*1000000)`, `=EXP(-E31/E30)`
- Yellow fill (user input), green fill (corrected value), no fill (calculated)

**Common cross-references:**
- Um, Un → System Data sheet
- Ur, Uc, Upl → Arrester sheet
- BIL, SIWV → Withstand sheet
- La (arrester distance) → System Data
- S (current steepness) → System Data or Tower & Line

---

## Critical Parameters Discovered in Field

**GIS inductance correction (CRITICAL):**
- Basic sheets often use L' = 1.0 µH/m (copy-paste from AIS/overhead templates)
- GIS actual value: 0.2-0.3 µH/m
- Impact: 75% reduction in separation voltage → better protection margin
- **Always flag and correct in High-Frequency sheet**

**Um verification (CRITICAL):**
- 132 kV → Um = 145 kV (IEC 60071-1 Table 2)
- 220 kV → Um = 245 kV
- 400 kV → Um = 420 kV
- **Verify before adding advanced sheets — propagates through all calculations**

**Earth-fault factor:**
- IEC 60071-2 cl. 4.2: ≤ 1.3 for effectively earthed systems
- If study uses 1.4 → TOV may exceed arrester capability
- **Flag for verification with utility/OETC standard**

---

## Completeness Levels

**40-45% (basic deterministic):**
- Standards, System Data, Withstand, Clearance, Arrester, Coordination, Summary
- Adequate for preliminary design / budget estimation
- Missing: energy, back-flashover, scenario analysis, HF corrections

**75-80% (enhanced deterministic with 6 advanced sheets):**
- All basic sheets + Energy, Tower, Scenarios, HF, Statistical, Cable
- Adequate for detailed design review (pending EMT verification)
- Missing: EMT simulation waveforms, parametric study

**100% (complete study):**
- 75-80% baseline + PowerFactory/PSCAD EMT simulation
- Lightning (back-flash + shielding), switching, TOV waveforms
- Parametric study (Rg, La, arrester rating sensitivity)
- Site-specific data validation
- Peer review and approval

---

## Worksheet Naming Convention

Suggested names (keep concise for tab visibility):
- `Energy Stress`
- `Tower & Line`
- `Overvoltage Scenarios`
- `High-Frequency`
- `Statistical`
- `Cable Coordination`

Alternatively (shorter):
- `Energy`
- `Tower`
- `Scenarios`
- `HF-Params`
- `Statistical`
- `Cable`

---

## Persian Language Note

When working with Persian/Farsi-speaking users:
- User prefers responses in Persian
- Technical content (equations, code) remains in English
- Sheet headers and titles can remain in English (international standard)
- Notes and explanations should be in Persian when user language detected
