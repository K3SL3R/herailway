# IEC 60071-2 Deterministic Audit — Worked Example

## Case: MAJAN 132 kV GIS (Jalaan Bani Bu Ali Wind IPP, Oman)

This is the chain-of-calculation audit performed on `Insulation_Coordination_Study_MAJAN_132kV_GIS_1.xlsx`. Follow this pattern for any deterministic coordination spreadsheet.

---

## Step 1 — Verify Um (IEC 60071-1 Table 2)

| System Un | Correct Um | Spreadsheet said | Verdict |
|-----------|-----------|-----------------|---------|
| 132 kV    | 145 kV    | 132 kV          | ❌ WRONG |

> **Rule:** For every spreadsheet audit, always check Um against the table first. This is the most common fatal error.

**Reference: IEC 60071-1:2019, Table 2**
- 33 kV → Um = 36 kV
- 66 kV → Um = 72.5 kV
- 132 kV → Um = 145 kV
- 220 kV → Um = 245 kV
- 400 kV → Um = 420 kV

---

## Step 2 — Re-compute Um/√3

```
Um/√3 = 145 / √3 = 83.72 kV
(Spreadsheet: 76.21 kV — wrong because Um was wrong)
```

---

## Step 3 — TOV at Arrester Location

```
TOV = (Um/√3) × earth_fault_factor = 83.72 × 1.4 = 117.20 kV
```

Check against IEC 60071-2 §4.2: earth-fault factor ≤ 1.3 for effectively earthed systems.
- At k=1.3: TOV = 108.83 kV (still > 108 kV arrester TOV cap ❌)
- At k=1.4: TOV = 117.20 kV (even further over ❌)

**Action:** Verify earth-fault factor with project/utility before changing Ur.

---

## Step 4 — Uc Adequacy

```
Required Uc ≥ Um/√3 = 83.72 kV
Selected Uc = 86 kV → PASS ✅
```

---

## Step 5 — TOV Capability

```
System TOV (k=1.4) = 117.20 kV
Arrester TOV cap (10 s) = 108 kV
Result: 108 < 117.20 → FAIL ❌
```

Even with k=1.3 → 108.83 kV > 108 kV → still FAIL ❌.

**Possible fixes:**
1. Upgrade arrester to Ur = 114 kV (e.g. Siemens 3EQ4 114)
2. Verify lower earth-fault factor with utility standard (OETC Oman)
3. Obtain actual TOV curve from manufacturer (may exceed datasheet min)

---

## Step 6 — Separation Effect (Urp-LI)

Spreadsheet formula: `=Upl + 2 × S × 100 × La / 300`

| Parameter | Value | Note |
|-----------|-------|------|
| Upl (LI @ 10 kA) | 248 kV | Siemens 3EQ4 108 datasheet |
| S | 20 kA/µs | = In (sheet links to cell) |
| La | 20 m | arrestor-to-equipment distance |
| ×100 factor | present | unexplained — stub/unit conversion? |
| c (implied) | 300 m/µs | speed of light |
| ΔV from formula | 266.67 kV | 2×20×100×20/300 |

**Result:** Urp-LI = 248 + 266.67 = **514.67 kV**

**Independent cross-check (inductive drop):**
```
ΔV = 2 × L' × La × S
   = 2 × 1 µH/m × 20 m × 20 kA/µs
   = 800 kV
→ Urp-LI = 248 + 800 = 1048 kV ← much higher
```

The spreadsheet's approach produces a different result from the simple inductive model. The ×100 factor dominates. This methodology should be documented by the engineer — if unexplained, flag it.

**Separation on SI:** SI = 0 (Ups = Urp-SI = 206 kV — no separation effect because switching surge rate-of-rise is negligible).

---

## Step 7 — Altitude Correction Ka

```
Ka = exp(m·(H-1000)/8150)
H=1000 m, m=1 → Ka = exp(0) = 1.0 ✅
```

Comment in spreadsheet said "H=300 m" but data cell said 1000 m → corrected note.

---

## Step 8 — Required Withstand

```
Kcd = 1.0 (deterministic, IEC 60071-2 cl. 6.3.4.1)
Ks = 1.05 (external insulation, cl. 7.3.5)

Ucw-LI = Urp-LI × Kcd = 514.67 × 1.0 = 514.67 kV
Urw-LI = Ucw-LI × Ks × Ka = 514.67 × 1.05 × 1.0 = 540.40 kV

Ucw-SI = Urp-SI × Kcd = 206 × 1.0 = 206 kV
Urw-SI = Ucw-SI × Ks × Ka = 206 × 1.05 × 1.0 = 216.30 kV
```

---

## Step 9 — LIWV Selection

Standard values per IEC 60071-1 Table 2 for Um=145 kV:

| LIWV (kV) | Pwr-Freq (kV) | Meets Urw-LI (540.4)? |
|-----------|---------------|----------------------|
| 450 | 185 | ❌ |
| 550 | 230 | ❌ |
| **650** | **275** | **✅ (margin 1.203)** |

---

## Step 10 — Protective Ratios

```
PR-LI = LIWV / Upl-eff = 650 / 514.67 = 1.263 ≥ 1.20 ✅
PR-SI = SIWV / Ups = 275 / 206 = 1.335 ≥ 1.15 ✅
```

---

## Step 11 — Creepage Distance

```
L_creep = Um × USCD = 145 × 25 = 3625 mm
(Spreadsheet said 6600 mm — computed with wrong Um=132 and wrong USCD=50)
```

Cross-check: was the pollution class "Very Heavy" (Class d, USCD ≥ 31) or "Heavy" (Class c, USCD = 25)? The spreadsheet was internally contradictory. Corrected to Heavy / USCD=25 → 3625 mm.

---

## Step 12 — Air Clearances (IEC 60071-2 Table A.1)

| LIWV (kV) | P-E (mm) | P-P (mm) |
|-----------|---------|---------|
| 650 | 1300 | 1500 |

---

## Step 13 — Pollution Class / USCD Cross-check

| Spreadsheet said | What it means | Contradiction |
|----------------|---------------|---------------|
| "V — Very Heavy" | IEC 60815 Class d, min USCD = 31 mm/kV | ❌ |
| USCD = 25 mm/kV | IEC 60815 Class c (Heavy), max USCD = 25 mm/kV | ❌ |
| Comment: "Class c, 25 mm/kV" | Correct for Heavy | ✅ |

**Fix:** Changed label to "c — Heavy (IEC 60815)" and kept USCD = 25 mm/kV.

---

## Quick Reference: Chain-of-Calculation

```
Un ──→ IEC 60071-1 Table 2 ──→ Um
                                   │
                                   ├──→ Um/√3 ──→ Uc check (≥ Um/√3)
                                   │            │
                                   │            └──→ × earthing factor ──→ TOV system
                                   │                                    │
                                   │                                    └──→ TOV cap check
                                   │
                                   ├──→ × USCD ──→ creepage distance
                                   │
Upl/Ups ──→ + separation ──→ Urp ──→ × Kcd ──→ Ucw ──→ × Ks × Ka ──→ Urw ──→ ≥ LIWV?
```

---

## Python Quick-Check Template

```python
import math

Um = 145       # verify from IEC 60071-1 Table 2
k  = 1.4       # earth-fault factor — verify with utility
Ur = 108       # arrester rated voltage
Uc = 86        # MCOV
tov_cap = 108  # 10s TOV capability (kV)
Upl = 248      # residual @ 10 kA
Ups = 206      # residual @ 1 kA

um_sqrt3 = Um / math.sqrt(3)
tov_sys  = um_sqrt3 * k
print(f"Um/√3 = {um_sqrt3:.2f} kV")
print(f"TOV system = {tov_sys:.2f} kV  {'✅' if tov_cap >= tov_sys else '❌'}")
print(f"Uc required = {um_sqrt3:.2f} kV max, selected = {Uc}  {'✅' if Uc >= um_sqrt3 else '❌'}")
```
