# Windows Drive Scanner — Full Analysis Script
# Save this as scan_drive.ps1 and run:
#   powershell -NoProfile -ExecutionPolicy Bypass -File scan_drive.ps1
#
# This script scans C:\ and all major subfolders, outputs sizes in GB.
# Requires ~3-5 minutes to run (recursive file enumeration is slow).

Write-Host "=== DRIVE C: SUMMARY ==="
$drive = Get-PSDrive C
$totalGB = [math]::Round(($drive.Used + $drive.Free)/1GB, 2)
$freeGB  = [math]::Round($drive.Free/1GB, 2)
$usedGB  = [math]::Round($drive.Used/1GB, 2)
$pctFree = [math]::Round($drive.Free/($drive.Used + $drive.Free)*100, 1)
Write-Host "Total: $totalGB GB | Used: $usedGB GB | Free: $freeGB GB ($pctFree%)"
Write-Host ""

# === SECTION 1: Top-level folders ===
Write-Host "=== TOP-LEVEL FOLDER SIZES ==="
$topFolders = @(
    "Windows", "Users", "Program Files", "Program Files (x86)",
    "ProgramData", "PerfLogs", "Intel", "AMD", "NVIDIA",
    "DRIVERS", "MSOCache", "Recovery"
)
foreach ($f in $topFolders) {
    $path = "C:\$f"
    if (Test-Path $path) {
        try {
            $size = (Get-ChildItem $path -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            Write-Host "  $f : $([math]::Round($size/1GB,2)) GB"
        } catch {
            Write-Host "  $f : access denied"
        }
    }
}
Write-Host ""

# === SECTION 2: Users breakdown ===
Write-Host "=== USERS SUB-FOLDERS ==="
Get-ChildItem "C:\Users" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        Write-Host "  $($_.Name) : $([math]::Round($size/1GB,2)) GB"
    } catch {
        Write-Host "  $($_.Name) : access denied"
    }
}
Write-Host ""

# === SECTION 3: Program Files (both) — top 20 ===
Write-Host "=== PROGRAM FILES — TOP 20 ==="
$pfResults = @()
@("C:\Program Files", "C:\Program Files (x86)") | ForEach-Object {
    $pfRoot = $_
    Get-ChildItem $pfRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            $suffix = if ($pfRoot -like "*(x86)*") { " (x86)" } else { "" }
            $pfResults += [PSCustomObject]@{Name="$($_.Name)$suffix"; SizeGB=[math]::Round($size/1GB,2)}
        } catch {}
    }
}
$pfResults | Sort-Object SizeGB -Descending | Select-Object -First 20 | ForEach-Object {
    Write-Host "  $($_.Name) : $($_.SizeGB) GB"
}
Write-Host ""

# === SECTION 4: Windows breakdown (top 15) ===
Write-Host "=== WINDOWS SUB-FOLDERS — TOP 15 ==="
$winResults = @()
Get-ChildItem "C:\Windows" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        $winResults += [PSCustomObject]@{Name=$_.Name; SizeGB=[math]::Round($size/1GB,2)}
    } catch {}
}
$winResults | Sort-Object SizeGB -Descending | Select-Object -First 15 | ForEach-Object {
    Write-Host "  $($_.Name) : $($_.SizeGB) GB"
}
Write-Host ""

# === SECTION 5: Large system files ===
Write-Host "=== LARGE SYSTEM FILES ==="
@("C:\hiberfil.sys", "C:\pagefile.sys", "C:\swapfile.sys") | ForEach-Object {
    if (Test-Path $_) {
        $fi = Get-Item $_ -Force -ErrorAction SilentlyContinue
        Write-Host "  $_ : $([math]::Round($fi.Length/1GB,2)) GB"
    } else {
        Write-Host "  $_ : not found"
    }
}
Write-Host ""

# === SECTION 6: Windows temp & cache folders ===
Write-Host "=== WINDOWS TEMP / CACHE FOLDERS ==="
@(
    "C:\Windows\Temp",
    "C:\Windows\SoftwareDistribution",
    "C:\Windows\Prefetch",
    "C:\Windows\Installer",
    "C:\Windows\Panther",
    "C:\Windows\CSC"
) | ForEach-Object {
    if (Test-Path $_) {
        try {
            $size = (Get-ChildItem $_ -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            Write-Host "  $_ : $([math]::Round($size/1GB,2)) GB"
        } catch {
            Write-Host "  $_ : access denied"
        }
    }
}
Write-Host ""

# === SECTION 7: System32 heavy subfolders ===
Write-Host "=== SYSTEM32 HEAVY (>100MB) ==="
$s32Results = @()
Get-ChildItem "C:\Windows\System32" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        if ($size -gt 100MB) {
            $s32Results += [PSCustomObject]@{Name=$_.Name; SizeGB=[math]::Round($size/1GB,2)}
        }
    } catch {}
}
$s32Results | Sort-Object SizeGB -Descending | ForEach-Object {
    Write-Host "  $($_.Name) : $($_.SizeGB) GB"
}
Write-Host ""

# === SECTION 8: AppData Local (current user) — top 20 ===
Write-Host "=== APPDATA LOCAL — TOP 20 ==="
$localResults = @()
Get-ChildItem "$env:LOCALAPPDATA" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        $localResults += [PSCustomObject]@{Name=$_.Name; SizeGB=[math]::Round($size/1GB,2)}
    } catch {}
}
$localResults | Sort-Object SizeGB -Descending | Select-Object -First 20 | ForEach-Object {
    Write-Host "  $($_.Name) : $($_.SizeGB) GB"
}
Write-Host ""

# === SECTION 9: AppData Roaming (current user) — top 15 ===
Write-Host "=== APPDATA ROAMING — TOP 15 ==="
$roamingResults = @()
Get-ChildItem "$env:APPDATA" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        $roamingResults += [PSCustomObject]@{Name=$_.Name; SizeGB=[math]::Round($size/1GB,2)}
    } catch {}
}
$roamingResults | Sort-Object SizeGB -Descending | Select-Object -First 15 | ForEach-Object {
    Write-Host "  $($_.Name) : $($_.SizeGB) GB"
}
Write-Host ""

# === SECTION 10: Package Cache & heavy ProgramData ===
Write-Host "=== PROGRAMDATA HEAVY (>100MB) ==="
Get-ChildItem "C:\ProgramData" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    try {
        $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        if ($size -gt 100MB) {
            Write-Host "  $($_.Name) : $([math]::Round($size/1GB,2)) GB"
        }
    } catch {}
}
Write-Host ""

# === SECTION 11: NVIDIA cache deep dive ===
Write-Host "=== NVIDIA CACHE (AppData\\Local) ==="
$nvPath = "$env:LOCALAPPDATA\NVIDIA"
if (Test-Path $nvPath) {
    Get-ChildItem $nvPath -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $size = (Get-ChildItem $_.FullName -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
            if ($size -gt 50MB) {
                Write-Host "  $($_.Name) : $([math]::Round($size/1GB,2)) GB"
            }
        } catch {}
    }
}
Write-Host ""

# === SECTION 12: Recycle Bin ===
Write-Host "=== RECYCLE BIN ==="
$rbPath = "C:\`$Recycle.Bin"
if (Test-Path $rbPath) {
    try {
        $size = (Get-ChildItem $rbPath -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        Write-Host "  Total: $([math]::Round($size/1GB,2)) GB"
    } catch {
        Write-Host "  access denied"
    }
}
Write-Host ""

Write-Host "=== SCAN COMPLETE ==="