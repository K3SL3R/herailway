---
name: windows-maintenance
description: "Windows disk analysis, cleanup, and maintenance — scan drive usage, identify large folders, reclaim space safely."
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [windows, disk-cleanup, maintenance, powershell]
---

# Windows Maintenance

Disk space analysis and cleanup for Windows 10/11. Use when the user needs to free space on a drive, identify what's consuming storage, or perform routine maintenance.

## Trigger phrases

- "clean up C drive"
- "free disk space"
- "what's taking up space on my PC"
- "windows disk cleanup"
- "analyze drive usage"

## Prerequisites

- PowerShell 5.1+ (built into Windows 10/11)
- May need admin access for some cleanup steps (WinSxS via DISM, certain temp folders)
- The agent runs via `terminal` tool using bash (MSYS/git-bash) — this creates a critical escaping pitfall

## Critical pitfall: PowerShell escaping under bash

When running multi-line PowerShell commands via the `terminal` tool on Windows, bash will expand `$variable` tokens in the command string before PowerShell sees them. This causes parse errors like:

```
Missing ')' in method call.
Unexpected token 'c/Users/Shayan.Free/1GB' in expression or statement.
```

**DO NOT inline complex PowerShell in `terminal(command=...)`**. Instead:

1. Write the PowerShell script to a `.ps1` file with `write_file`
2. Execute it: `powershell -NoProfile -ExecutionPolicy Bypass -File "C:\path\to\script.ps1"`

Simple one-liners that don't use `$_`, `$_.Property`, or computed variables can be inlined if they use only literal strings.

## Phase 1: Drive overview

Run this baseline to understand the situation:

```powershell
# PSDrive summary
Get-PSDrive C | Select-Object Used,Free | Format-List

# Or via WMIC
wmic logicaldisk where "DeviceID='C:'" get Size,FreeSpace /format:list
```

Interpret: < 10% free = critical. < 20% = warning.

## Phase 2: Top-level folder scan

Run the bundled scan script (`scripts/scan-drive.ps1`) for a complete breakdown:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts/scan-drive.ps1"
```

This scans C:\ top-level directories, Users, Program Files, ProgramData, Windows subfolders, System32 heavy folders, AppData Local/Roaming, NVIDIA cache, and Recycle Bin — producing a full GB breakdown in one run (~3-5 minutes). The script lives in the skill's `scripts/` directory.

If you need a narrower scan (specific folders only), use the inline patterns below.

Key folders to always check:

| Folder | What it is | Cleanup safety |
|--------|-----------|----------------|
| `Windows\WinSxS` | Side-by-side component store | DISM only, limited |
| `Windows\System32\DriverStore` | Driver packages | `pnputil` or Disk Cleanup |
| `Windows\Installer` | MSI installer cache | Caution — needed for uninstall/repair |
| `Windows\SoftwareDistribution` | Windows Update downloads | Safe after updates installed |
| `Windows\Temp` | System temp | Safe |
| `Windows\Panther` | Upgrade logs | Safe after successful upgrade |
| `Windows\Prefetch` | Boot optimization | Safe |
| `ProgramData\Package Cache` | Visual Studio / SDK installers | Safe — used only for install/repair |
| `Users\<name>\AppData\Local\NVIDIA\DXCache` | NVIDIA shader cache | Safe — auto-rebuilds |
| Users\\<name>\\AppData\\Local\\BraveSoftware | Brave browser data | Clear cache folders (after killing process). **Service Worker** folder often 1-2 GB alone |
| `Users\<name>\AppData\Local\Temp` | User temp | Safe |
| `Users\<name>\AppData\Local\Microsoft\Windows\INetCache` | IE/Edge cache | Safe |
| `$Recycle.Bin` | Recycle bin | Empty via Desktop |

## Phase 3: Known safe auto-cleanup (agent can execute)

These are safe, documented, and built into Windows:

1. **Disk Cleanup (cleanmgr)** — the built-in tool:
   ```
   cleanmgr /sagerun:1   (after /sageset:1 to configure)
   cleanmgr /verylowdisk (automatic mode)
   ```

2. **Delete Windows Update cache**:
   ```
   net stop wuauserv
   Remove-Item "C:\Windows\SoftwareDistribution\Download\*" -Recurse -Force
   net start wuauserv
   ```

3. **Delete temp folders**:
   ```
   Remove-Item "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
   Remove-Item "$env:LOCALAPPDATA\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue
   ```

4. **Delete NVIDIA DXCache** (shader cache — auto-rebuilds, often 2-6 GB):
   ```
   Remove-Item "$env:LOCALAPPDATA\NVIDIA\DXCache\*" -Recurse -Force
   ```

5. **Delete Package Cache** (VS/SDK installer cache, needs admin):
   ```
   Remove-Item "C:\ProgramData\Package Cache\*" -Recurse -Force
   ```

6. **Empty recycle bin**:
   ```
   Clear-RecycleBin -Force
   ```

7. **Delete Windows upgrade logs** (Panther, needs admin):
   ```
   Remove-Item "C:\Windows\Panther\*" -Recurse -Force
   ```

8. **Clear Brave browser cache** (can reclaim 2-10 GB):
   - First kill all Brave processes: `Get-Process brave -ErrorAction SilentlyContinue | Stop-Process -Force`
   - Then clear the four cache folders:
     ```
     Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache\*" -Recurse -Force
     Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Code Cache\*" -Recurse -Force
     Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Local Storage\*" -Recurse -Force
     Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Service Worker\*" -Recurse -Force
     ```
   - ⚠️ Breaking change vs Phase 2 note: this is now proven safe and effective. The in-browser method preserves profile but the folder-deletion method is faster and equally safe (only cached data is lost; passwords, bookmarks, extensions, and settings survive).

## Phase 4: Needs human review (do NOT execute without user approval)

These require user decision because they affect functionality:

1. **WinSxS cleanup via DISM** — can reclaim 3-6 GB but needs admin:
   ```
   dism /online /cleanup-image /startcomponentcleanup /resetbase
   ```

2. **Windows Installer cache** (`C:\Windows\Installer`) — needed for uninstall/repair of apps. Only safe after verifying no apps will need repair.

3. **Microsoft Office components** — can uninstall unused components (e.g., Visio Viewer, Office Proofing Tools for unused languages).

4. **Unused Visual C++ Redistributables** — `Program Files (x86)\Microsoft` may contain many versions. Check Apps & Features for redundant VC++ runtimes.

5. **Redundant .NET Desktop Runtimes** — it's common to find 6-8 versions totaling 1.5-2 GB. See `references/dotnet-runtime-redundancy.md` for which versions are safe to remove (.NET 5.0 and 6.0 are EOL).

6. **NVIDIA driver installer files** — `C:\ProgramData\NVIDIA Corporation\Downloader` and `C:\ProgramData\NVIDIA` contain old driver installers. Safe to delete old versions.

7. **ms-playwright** (`AppData\Local\ms-playwright`) — browser binaries for Playwright testing. Can be removed if not actively using Playwright.

8. **npm-cache** (`AppData\Local\npm-cache`) — safe to clear via `npm cache clean --force`.

9. **Brave browser cache** — can be massive (2-10 GB). The biggest consumer is often **Service Worker** (`User Data\Default\Service Worker`) — cached offline scripts for sites like Gmail, Telegram Web, WhatsApp Web. See `references/brave-cache-cleanup.md` for full procedure and folder breakdown.

   **Safe direct deletion approach:**
   - Kill all Brave processes first: `Get-Process brave | Stop-Process -Force`
   - Then delete all 4 cache folders (Cache, Code Cache, Local Storage, Service Worker)
   - Only cached site data is lost; passwords, bookmarks, extensions, and settings survive.

10. **WSL distributions** — `System32\lxss` holds WSL data. If WSL is not used, can uninstall distributions.

11. **Unused Microsoft Store apps** — `AppData\Local\Packages` — uninstall from Settings → Apps rather than deleting folders directly.

## Cleanup priority order (most safe first)

| Priority | Item | Typical reclaim | Risk |
|----------|------|-----------------|------|
| 1 | NVIDIA DXCache | 2-6 GB | None |
| 2 | Temp folders | 0-2 GB | None |
| 3 | Package Cache | 1-4 GB | Minimal |
| 4 | Windows Update cache | 0-1 GB | None |
| 5 | Panther upgrade logs | 0.5-1 GB | None |
| 6 | Recycle Bin | varies | None |
| 7 | Browser cache (Brave) | 2-10 GB | Minimal — kill process first, then delete Cache/Code Cache/Local Storage/Service Worker folders |
| 8 | Old driver packages | 1-4 GB | Low |
| 9 | WinSxS (DISM) | 3-6 GB | Low |
| 10 | Unused apps | varies | Medium |
| 11 | Windows Installer cache | 1-4 GB | Medium |
| 12 | User data (review manually) | varies | High |

## Verification

After cleanup, measure the actual reclaimed space. Use WMIC for reliable numeric output (avoids PowerShell formatting issues):

```bash
wmic logicaldisk where "DeviceID='C:'" get Size,FreeSpace /format:list
```

This returns raw byte values — parse and convert to GB: `free_gb = round(free_bytes / 1024**3, 2)`.

Compare before/after free space to confirm each cleanup step's impact. The `execute_code` tool is ideal for these calculations since it can parse WMIC output and compute deltas cleanly.

For verifying specific folders were actually emptied, use `.ps1` scripts:

```powershell
$sz = (Get-ChildItem 'C:\Windows\Panther' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
Write-Host "Panther: $([math]::Round($sz/1MB,2)) MB"
```

## Related tools

- `cleanmgr` (built-in Disk Cleanup)
- `dism` (Deployment Image Servicing — WinSxS cleanup)
- `pnputil` (driver package management)
- Windows Settings → System → Storage → Temporary files