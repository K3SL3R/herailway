# .NET Desktop Runtime Version Redundancy

## Pattern

Windows systems that run many development tools accumulate multiple versions of **Microsoft Windows Desktop Runtime** — each ~200-300 MB. It's common to find 6-8 versions, totaling 1.5-2 GB, where only the latest 1-2 are actively needed.

## Real-world example (July 2026, Windows 11 24H2)

Found 8 entries registered in "Programs and Features":

| Version | Size |
|---------|------|
| 10.0.9 (x64) | 287 MB |
| 9.0.17 (x64) | 227 MB |
| 8.0.28 (x64) | 216 MB |
| 8.0.28 (x86) | 201 MB |
| 6.0.36 (x64) | 211 MB |
| 6.0.36 (x86) | 195 MB |
| 6.0.28 (x64) | 210 MB |
| 5.0.17 (x64) | 204 MB |
| **Total** | **1.71 GB** |

## Which to keep

- **.NET 8.0** is the current LTS — keep at least one architecture (x64)
- **.NET 9.0** is the current STS — keep if actively developing against it
- **.NET 10.0** is preview — keep if developing against it
- **.NET 5.0 and 6.0** are end-of-life (EOL) — safe to remove unless a specific legacy app requires them

## How to check what a specific app needs

Check the app's installation folder for `.runtimeconfig.json` which specifies the target framework version:
```
Get-ChildItem "C:\Program Files" -Recurse -Filter "*.runtimeconfig.json" -ErrorAction SilentlyContinue | Select-String "Microsoft.NETCore.App"
```

Or check the app publisher's documentation for minimum .NET version requirements.

## Removal

Uninstall from **Settings → Apps → Installed apps** or via `winget`:
```
winget uninstall "Microsoft.WindowsDesktopRuntime.6"
```

Never delete runtime files directly from disk — always use proper uninstall to clean registry entries too.

## Estimated space reclaimable

- Removing 5.0 + 6.0 versions: ~810 MB
- Removing all but latest LTS: ~1.3-1.5 GB