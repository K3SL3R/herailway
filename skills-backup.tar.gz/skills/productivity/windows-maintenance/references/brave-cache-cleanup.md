# Brave Browser Cache Breakdown

## Folder structure

Brave stores browser cache in four subdirectories under:
```
%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data\Default\
```

| Folder | Purpose | Typical size | Safe to delete? |
|--------|---------|--------------|-----------------|
| `Cache` | Images, CSS, JS from visited sites | 100-500 MB | ✅ Safe |
| `Code Cache` | Compiled/optimized JS code cache | 200-600 MB | ✅ Safe |
| `Local Storage` | Site-specific settings (login tokens, preferences) | 10-50 MB | ✅ Safe (sites may ask to re-login) |
| `Service Worker` | Offline-capable site scripts (Gmail, Telegram Web, WhatsApp Web, etc.) | **500 MB - 2+ GB** | ✅ Safe |

## The Service Worker surprise

Service Worker cache is often the **single largest** reclaimable item in a user profile. In one real session (July 2026), Service Worker was **1.69 GB** — nearly 75% of total Brave cache (2.26 GB). Most users are unaware this folder even exists.

## What survives deletion

The following data is stored in `User Data\Default\` but **outside** the four cache folders above, and is NOT affected by clearing the cache:

- Passwords (Login Data)
- Bookmarks
- Extensions
- History
- Preferences/settings
- Cookies

## Procedure

1. **Kill all Brave processes:**
   ```powershell
   Get-Process brave -ErrorAction SilentlyContinue | Stop-Process -Force
   ```

2. **Verify Brave is fully closed:**
   ```powershell
   if (Get-Process brave -ErrorAction SilentlyContinue) { Write-Host "Still running!" } else { Write-Host "Fully closed" }
   ```

3. **Delete all four cache folders:**
   ```powershell
   Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Cache\*" -Recurse -Force
   Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Code Cache\*" -Recurse -Force
   Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Local Storage\*" -Recurse -Force
   Remove-Item "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Service Worker\*" -Recurse -Force
   ```

4. **Verify the folders are empty:**
   ```powershell
   (Get-ChildItem "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data\Default\Service Worker" -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
   ```
   Should return 0.

## Post-cleanup behavior

- First visit to each site will be slightly slower (cache rebuilds)
- Sites using Service Workers (Gmail, etc.) will prompt to enable offline mode again on first visit
- No data loss beyond cached assets
- Browser restarts automatically if you open it again