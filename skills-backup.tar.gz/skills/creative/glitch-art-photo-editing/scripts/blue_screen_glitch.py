#!/usr/bin/env python3
import sys
from PIL import Image
import numpy as np
import cv2
import random

def blue_screen_glitch(input_path, output_path, intensity=0.3, seed=None):
    """Generate blue-and-white glitch art (BSOD style) from input image."""
    if seed:
        np.random.seed(seed)
    
    # Load image
    img = cv2.imread(input_path)
    if img is None:
        print(f"Error: Could not load {input_path}")
        return
    
    height, width = img.shape[:2]
    
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply strong contrast and threshold to get two-tone effect
    # Use adaptive contrast to preserve some structure
    gray = cv2.equalizeHist(gray)
    
    # Create blue background with white elements
    # Dark pixels → bright blue, Light pixels → white
    blue_channel = np.full((height, width), 255, dtype=np.uint8)  # Full blue
    green_channel = np.zeros((height, width), dtype=np.uint8)
    red_channel = np.zeros((height, width), dtype=np.uint8)
    
    # Map grayscale to blue-white gradient
    # Pixels < 128 → blue, pixels >= 128 → white
    threshold = 128
    white_mask = gray > threshold
    
    # For white areas, set all channels to 255
    blue_channel[white_mask] = 255
    green_channel[white_mask] = 255
    red_channel[white_mask] = 255
    
    # For blue areas, keep blue high, others low
    blue_channel[~white_mask] = 255
    green_channel[~white_mask] = 0
    red_channel[~white_mask] = 0
    
    # Merge into BGR image
    img = cv2.merge([blue_channel, green_channel, red_channel])
    
    # RGB channel shift for glitch effect
    b, g, r = cv2.split(img)
    shift_x = random.randint(5, 15)
    shift_y = random.randint(5, 15)
    r_shift = np.roll(r, shift_x, axis=1)
    b_shift = np.roll(b, -shift_x, axis=0)
    img = cv2.merge([b_shift, g, r_shift])
    
    # Scan-line effect (horizontal distortion)
    for y in range(0, height, 2):
        img[y:y+1, :] = cv2.GaussianBlur(img[y:y+1, :], (3, 3), 0)
    for y in range(1, height, 3):
        img[y:y+1, :] = (img[y:y+1, :] * 0.4).astype(np.uint8)
    
    # Random pixel corruption - white noise on blue background
    corruption_rate = intensity
    corruption_mask = np.random.rand(height, width) < corruption_rate
    
    # Create white noise pixels
    random_pixels = np.random.choice([0, 255], size=(height, width, 3), p=[0.3, 0.7])
    random_pixels = random_pixels.astype(np.uint8)
    
    # For corrupted pixels, use random white/blue
    img[corruption_mask] = random_pixels[corruption_mask]
    
    # Add horizontal glitch lines (data corruption bars)
    num_glitch_lines = random.randint(3, 8)
    for _ in range(num_glitch_lines):
        y_pos = random.randint(0, height - 10)
        line_height = random.randint(1, 5)
        glitch_color = [255, 255, 255] if random.random() > 0.5 else [255, 0, 0]
        img[y_pos:y_pos+line_height, :] = glitch_color
    
    cv2.imwrite(output_path, img)
    print(f"Blue-screen glitch image saved: {output_path}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: blue_screen_glitch.py <input.jpg> <output.jpg> [intensity 0-1] [seed]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    intensity = float(sys.argv[3]) if len(sys.argv) > 3 else 0.3
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else None
    
    blue_screen_glitch(input_file, output_file, intensity, seed=seed)
