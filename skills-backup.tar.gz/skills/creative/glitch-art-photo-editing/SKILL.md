---
name: glitch-art-photo-editing
description: Create glitch art and digital distortion effects in photos.
version: 0.1.0
author: Hermes
platforms: [windows, macos, linux]
metadata:
  hermes:
    tags: [Glitch Art, Photo Editing, Digital Distortion, VFX]
---

# Glitch Art Photo Editing

Create corrupted digital aesthetic photos with scan-line distortion, color separation, pixel corruption, and CRT-like effects. This skill covers both automated tools and manual editing techniques to achieve the glitch art visual style.

## When to Use

- Adding digital decay or system-failure themes to photos
- Creating VFX for album artwork, posts, or digital art pieces
- Replicating the corrupted framebuffer / analog-video-error look
- Deliberately distorting portraits or landscapes for artistic effect
- Combining multiple images with scan-line and RGB-shift overlays

## Prerequisites

Install required tools via `terminal`:

```bash
uv pip install pillow numpy opencv-python
```

For advanced glitch generation, optional tools:
- **FFmpeg** (scan-line overlays, video-to-frame export)
- **GIMP** (manual layer-based distortion)
- **ImageMagick** (batch corruption effects)

## How to Run

Glitch effects are generated via Python scripts (invoke through the `terminal` tool) or manual layer editing in GIMP. The quick reference lists common CLI commands; the Procedure section walks through a full end-to-end example.

## Quick Reference

**Python glitch effect library:**
```python
from PIL import Image
import numpy as np
import cv2

# RGB channel shift (3-channel separation)
img = cv2.imread("input.jpg")
b, g, r = cv2.split(img)
r_shift = np.roll(r, 5, axis=1)
b_shift = np.roll(b, -5, axis=0)
glitch = cv2.merge([b_shift, g, r_shift])

# Scan-line overlay (horizontal stripes)
height, width = glitch.shape[:2]
for y in range(0, height, 3):
    glitch[y:y+2, :] = glitch[y:y+2, :] * 0.3

# Random pixel corruption
corruption = np.random.rand(height, width, 3) * 255
mask = np.random.rand(height, width) < 0.05
glitch[mask] = corruption[mask].astype(np.uint8)

cv2.imwrite("glitch_output.jpg", glitch)
```

**GIMP manual approach:**
1. Duplicate layer 3× (red, green, blue separation)
2. Apply channel mixer or color curves per layer
3. Shift each layer (offset filter) by 10–20 pixels
4. Add scan-line pattern overlay (new layer, brush strokes or filtered noise)
5. Increase saturation and contrast

**FFmpeg scan-line overlay:**
```bash
ffmpeg -i input.jpg -vf "split=2[a][b];[a]scale=1920:1080[scaled];[b]scale=1920:1080,format=rgba,geq=r='if(mod(Y,3),r(X,Y),0)':g='if(mod(Y,3),g(X,Y),0)':b='if(mod(Y,3),b(X,Y),0)':a='255'[scan];[scaled][scan]overlay=format=auto[out]" -map "[out]" output.jpg
```

## Procedure

### Method 1: Python Glitch Generator (Fastest)

**Standard RGB glitch effect:**

1. Save this Python script as `glitch_generator.py` via `write_file`:

```python
#!/usr/bin/env python3
import sys
from PIL import Image
import numpy as np
import cv2
import random

def glitch_image(input_path, output_path, intensity=0.3, scan_line=True, rgb_shift=True, seed=None):
    """Generate glitch art from input image."""
    if seed:
        np.random.seed(seed)
    
    # Load image
    img = cv2.imread(input_path)
    if img is None:
        print(f"Error: Could not load {input_path}")
        return
    
    height, width = img.shape[:2]
    
    # RGB channel shift
    if rgb_shift:
        b, g, r = cv2.split(img)
        shift_x = random.randint(5, 20)
        shift_y = random.randint(5, 20)
        r_shift = np.roll(r, shift_x, axis=1)
        b_shift = np.roll(b, -shift_x, axis=0)
        img = cv2.merge([b_shift, g, r_shift])
    
    # Scan-line effect
    if scan_line:
        for y in range(0, height, 2):
            img[y:y+1, :] = cv2.GaussianBlur(img[y:y+1, :], (3, 3), 0)
        for y in range(1, height, 3):
            img[y:y+1, :] = (img[y:y+1, :] * 0.5).astype(np.uint8)
    
    # Random pixel corruption
    corruption_rate = intensity
    corruption_mask = np.random.rand(height, width) < corruption_rate
    random_pixels = np.random.randint(0, 255, (height, width, 3), dtype=np.uint8)
    img[corruption_mask] = random_pixels[corruption_mask]
    
    # Increase contrast and saturation (HSV space)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 1] = np.clip(hsv[:, :, 1] * 1.3, 0, 255)
    hsv[:, :, 2] = np.clip(hsv[:, :, 2] * 1.1, 0, 255)
    img = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)
    
    cv2.imwrite(output_path, img)
    print(f"Glitch image saved: {output_path}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: glitch_generator.py <input.jpg> <output.jpg> [intensity 0-1] [seed]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    intensity = float(sys.argv[3]) if len(sys.argv) > 3 else 0.3
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else None
    
    glitch_image(input_file, output_file, intensity, seed=seed)
```

2. Invoke through the `terminal` tool:

```bash
python3 glitch_generator.py input.jpg output.jpg 0.25
```

3. Adjust intensity (0.1 = subtle, 0.5 = heavy corruption). Use `seed` parameter to make results repeatable:

```bash
python3 glitch_generator.py input.jpg output_v2.jpg 0.4 42
```

**Blue-screen variant (BSOD style):**

For the classic blue-and-white glitch aesthetic, use the included `scripts/blue_screen_glitch.py`:

```bash
python3 scripts/blue_screen_glitch.py input.jpg output_blue.jpg 0.3
```

This variant:
- Converts image to grayscale, then maps to electric blue (#0000FF) and white
- Adds horizontal glitch bars (3-8 random corruption lines)
- Applies scan-line and RGB shift effects
- Produces the "Blue Screen of Death" corrupted display aesthetic

### Method 2: Manual GIMP Editing (Full Control)

1. Open image in GIMP.
2. Layer → Duplicate Layer (create 3 copies for RGB channels).
3. Set layer blend modes: Layer 1 = Red, Layer 2 = Green, Layer 3 = Blue.
4. For each layer, use Colors → Curves or Hue-Saturation to isolate color channel.
5. Use Layer → Transform → Offset to shift each by 8–15 pixels.
6. Create a new layer for scan-lines: Filters → Render → Pattern → Grid (set spacing to 2–3px height).
7. Set scan-line layer to Multiply or Overlay blend mode, reduce opacity to 40–60%.
8. Add pixel corruption: Select → By Color Range (random), then Edit → Fill with noise.
9. Flatten and export as JPEG.

### Method 3: Batch Processing (Multiple Images)

Create `batch_glitch.sh` to process a folder:

```bash
#!/bin/bash
for img in input_folder/*.jpg; do
    filename=$(basename "$img")
    output="output_folder/glitch_${filename}"
    python3 glitch_generator.py "$img" "$output" 0.3
    echo "Processed: $filename"
done
```

Invoke:
```bash
chmod +x batch_glitch.sh
./batch_glitch.sh
```

## Pitfalls

- **RGB shift too extreme:** Shifts >30px can make the image unrecognizable. Start at 5–15px.
- **Scan-lines too dense:** Lines every 1–2 pixels look too artificial; use 3–4px spacing for CRT realism.
- **Oversaturation:** High saturation + glitch effects can look garish. Keep saturation boost to 1.2–1.4×.
- **Corruption rate:** Rates >0.5 destroy the image entirely. Keep between 0.1–0.4 for recognizable results.
- **GIMP export:** Use JPEG quality 85–95 to preserve glitch detail; PNG may compress artifacts away.
- **OpenCV color space:** `cv2.imread()` loads BGR, not RGB. For export, use `cv2.imwrite()` which handles BGR→RGB automatically.
- **Windows path handling:** On Windows under git-bash, OpenCV requires Windows-style paths (`C:\Users\...`) in script arguments, not MSYS paths (`/c/Users/...`). The bash shell accepts both, but OpenCV's internal path parser does not. Always pass Windows-style paths when invoking Python scripts that use `cv2.imread()` or `cv2.imwrite()`.

## Verification

Test the script with a sample image:

```bash
python3 glitch_generator.py input.jpg test_output.jpg 0.2
```

Verify output file exists and displays scan-line/RGB-shift artifacts:

```bash
ls -lh test_output.jpg
file test_output.jpg
```

Expected output: "JPEG image data" and file size ~100–500 KB (depends on source). Visually inspect for:
- RGB channel separation (color fringing on edges)
- Horizontal scan-lines (reduced brightness every 2–4 pixels)
- Random pixel noise (1–20% corrupted pixels)
- Enhanced saturation (colors appear more vivid, especially blues/cyans)
